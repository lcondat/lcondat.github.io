These Matlab files implement the joint demosaicking/denoising method, as described in the article:

L. Condat and S. Mosaddegh, "Joint Demosaicking and Denoising by Total Variation Minimization," Proc. of IEEE ICIP, Sept. 2012, Orlando, USA. 

Files written by Laurent Condat, CNRS research fellow in GIPSA-lab, a research unit of the University of Grenoble, France.
For any comment, don't hesitate to e-mail me: laurent.condat@gipsa-lab.grenoble-inp.fr

Version 1.0, Jan. 5, 2011.

Tested under Windows with Matlab 7.9.0 

Support for the Hirakawa and Condat CFAs in addition to the Bayer CFA.

The main.m file is a demo processing the 24 Kodak images. You have to set the correct path to the Kodak images on your computer.

demosa.m implements the demosaicking method by frequency selection described in the article:
	L Condat, "A Simple, Fast and Efficient Approach to Denoisaicking: Joint Demosaicking and Denoising", 
	IEEE ICIP, Hong-Kong, China, 2010.
The demosaicked image is used as initialization for the TV-based iterative method.
The Wiener-like filters for estimating the denoised chrominance are solutions of linear systems. They are computed during the denoisaicking process, because they depend on the noise level sigma. 
The corresponding .mat files can be re-generated using the programs MMSEfiltersXXX.m, but be patient, the process is very slow!

The PSNR between the reconstructed and the reference images can be computed using the script computepsnr.m