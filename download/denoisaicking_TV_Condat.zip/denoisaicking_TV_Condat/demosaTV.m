function [Y] = demosaTV(Z,X,C,lambda,nbiter)
% Z is the mosaicked image
% X is an initial estimate of the demosaicked image
% C is the CFA as a color image, with values in [0,1]

alpha=0.1;
beta=1/alpha/8.01;
[n,m,ch]=size(Z);
Ux=zeros(n,m,3);
Uy=zeros(n,m,3);
Y=X;
Y2=X;

for iter=1:nbiter
	Ux(1:n-1,:,:)=Ux(1:n-1,:,:)+(Y2(2:n,:,:)-Y2(1:n-1,:,:))*alpha;
	Uy(:,1:m-1,:)=Uy(:,1:m-1,:)+(Y2(:,2:m,:)-Y2(:,1:m-1,:))*alpha;
	Lx=sum(Ux,3)/3.0;
	Ux(:,:,1)=Ux(:,:,1)-Lx;
	Ux(:,:,2)=Ux(:,:,2)-Lx;
	Ux(:,:,3)=Ux(:,:,3)-Lx;
	Ly=sum(Uy,3)/3.0;
	Uy(:,:,1)=Uy(:,:,1)-Ly;
	Uy(:,:,2)=Uy(:,:,2)-Ly;
	Uy(:,:,3)=Uy(:,:,3)-Ly;
	EL=sqrt((Lx.^2+Ly.^2)*3.0);	%sqrt of luminance energy
	EC=sqrt(dot(Ux,Ux,3)+dot(Uy,Uy,3));	%sqrt of chrominance energy
	EL=min(1,lambda./EL);
	Lx=Lx.*EL;
	Ly=Ly.*EL;
	EC=min(1,1.0./EC);
	Ux(:,:,1)=Ux(:,:,1).*EC+Lx;
	Ux(:,:,2)=Ux(:,:,2).*EC+Lx;
	Ux(:,:,3)=Ux(:,:,3).*EC+Lx;
	Uy(:,:,1)=Uy(:,:,1).*EC+Ly;
	Uy(:,:,2)=Uy(:,:,2).*EC+Ly;
	Uy(:,:,3)=Uy(:,:,3).*EC+Ly;
	Y2=Y;
	Y(2:n,:,:)=Y(2:n,:,:)+(Ux(2:n,:,:)-Ux(1:n-1,:,:))*beta;
	Y(:,2:m,:)=Y(:,2:m,:)+(Uy(:,2:m,:)-Uy(:,1:m-1,:))*beta;
	E=(Z-dot(C,Y,3))./dot(C,C,3);
	Y(:,:,1)=Y(:,:,1)+C(:,:,1).*E;
	Y(:,:,2)=Y(:,:,2)+C(:,:,2).*E;
	Y(:,:,3)=Y(:,:,3)+C(:,:,3).*E;
	Y2=2*Y-Y2;
	[iter,max(abs(Y2(:)-Y(:)))]
end
return;


