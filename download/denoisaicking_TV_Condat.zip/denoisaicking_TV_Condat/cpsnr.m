function [val] = cpsnr(X1,X2,border)

[n,m,ch]=size(X1);
diff=X1(1+border:n-border,1+border:m-border,:)-X2(1+border:n-border,1+border:m-border,:);
mse=mean(diff(:).^2);
val=10*log10(255*255/mse);
