function []= MMSEfilters()
	sigma=20;
	border=10; %nb pixels ignored on boundaries
	%semisize=4; %patchs 9*9
	semisize=6; %patchs 13*13
	
	filtersize = 2*semisize+1;
	aux=filtersize*filtersize;
	AGM=zeros(aux,aux);
	bGM=zeros(aux,1);
	ARB=zeros(aux,aux);
	bRB=zeros(aux,1);
	total=0;
	for ima=1:24
		name=sprintf('/Users/lcondat/lcondat-reseau/prog/images/couleur/kodim%02i.tif',ima);
		I=imread(name,'tif');
		[n,m,ch]=size(I);
		if n>m
			I=imrotate(I,90);
			[n,m,ch]=size(I);
		end
		I=double(I);
		ChromiGM=I(:,:,2)*(2/sqrt(6))-I(:,:,1)/sqrt(6)-I(:,:,3)/sqrt(6);
		ChromiRB=I(:,:,1)/sqrt(2)-I(:,:,3)/sqrt(2);
		
		%%downsampling to CFA (Bayer pattern) image 
		Mosa(1:n,1:m)=I(:,:,2);
		Mosa(1:2:n,2:2:m)=I(1:2:n,2:2:m,1);
		Mosa(2:2:n,1:2:m)=I(2:2:n,1:2:m,3);
		
		Carrier=ones(n,m);
		Carrier(1:2:n,2:2:m)=-1;
		Carrier(2:2:n,1:2:m)=-1;
		ModulatedGM=Carrier.*Mosa*(4/sqrt(6));
		Carrier=ones(n,m);
		Carrier(1:n,1:2:m)=-1;
		ModulatedRBH=Carrier.*Mosa*(4/sqrt(2));
		Carrier=ones(n,m);
		Carrier(2:2:n,1:m)=-1;
		ModulatedRBV=Carrier.*Mosa*(4/sqrt(2));
		
		for i=1+border:n-border
			for j=1+border:m-border
				patch=ModulatedGM(i-semisize:i+semisize,j-semisize:j+semisize);
				patch=sympart(patch);
				AGM=AGM+patch(:)*patch(:).';
				bGM=bGM+patch(:)*ChromiGM(i,j);
				patch=ModulatedRBH(i-semisize:i+semisize,j-semisize:j+semisize);
				patch=sympart(patch);
				patch2=ModulatedRBV(i-semisize:i+semisize,j-semisize:j+semisize);
				patch2=sympart(patch2).';
				patch=(patch+patch2)/2;	%au lieu d'avoir les poids 1/2,1/2 je pourrais mettre  
										%les poids d'un algo de classif non linéaire entre H et V
				ARB=ARB+patch(:)*patch(:).';
				bRB=bRB+patch(:)*ChromiRB(i,j);
				total=total+1;
			end
		end
		ima
	end
	AGM = AGM / total;
	bGM = bGM / total;
	ARB = ARB / total;
	bRB = bRB / total;	
	name=sprintf('filtersmat%d.mat',filtersize);
	save filtersmat filtersize AGM bGM ARB bRB
end

function [Y] = sympart(X)
	[n,m]=size(X);
	Y=(X+X(n:-1:1,:)+X(:,m:-1:1)+X(n:-1:1,m:-1:1))/4;
end