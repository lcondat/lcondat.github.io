function [Y] = demosa(X,cfa,sigma)

[n,m,ch]=size(X);

if (cfa==0)
	% G R
	% B G
	load filtersmat13.mat
	I=eye(filtersize*filtersize);
	filterGM=pinv(AGM+(sigma*sigma*8/3)*I)*bGM;
	filterGM = reshape(filterGM,filtersize,filtersize);
	%filterGM = reshape(filterGM/sum(filterGM(:)),filtersize,filtersize);
	filterRB=pinv(ARB+(sigma*sigma*4)*I)*bRB;
	filterRB = reshape(filterRB,filtersize,filtersize);
	%filterRB = reshape(filterRB/sum(filterRB(:)),filtersize,filtersize);
	
	Carrier=ones(n,m);
	Carrier(1:2:n,2:2:m)=-1;
	Carrier(2:2:n,1:2:m)=-1;
	ChromiGM=filter2(filterGM,Carrier.*X)/3;
	Carrier=ones(n,m);
	Carrier(1:n,1:2:m)=-1;
	ChromiRB=filter2(filterRB,Carrier.*X);
	Carrier=ones(n,m);
	Carrier(2:2:n,1:m)=-1;
	ChromiRB=ChromiRB+filter2(filterRB.',Carrier.*X);
	Carrier=ones(n,m);
	Carrier(1:2:n,2:2:m)=-1;
	Carrier(2:2:n,1:2:m)=-1;
	X=X-(1+3*Carrier).*ChromiGM;
	Carrier=ones(n,m);
	Carrier(1:2:n,1:2:m)=0;
	Carrier(2:2:n,2:2:m)=0;
	Carrier(2:2:n,1:2:m)=-1;
	X=X-Carrier.*ChromiRB;
	
elseif (cfa==1)
	load filtersmatHirakawa13.mat
	I=eye(filtersize*filtersize);
	filterGM=pinv(AGM+(sigma*sigma*8/3)*I)*bGM;
	filterGM = reshape(filterGM,filtersize,filtersize);
	%filterGM(:)=1/169;
	filterRB=pinv(ARB+(sigma*sigma*8)*I)*bRB;
	filterRB = reshape(filterRB,filtersize,filtersize);
	%filterRB(:)=1/169;
	
	CarrierRB=ones(n,m);
	CarrierRB(1:2:n,2:2:m)=-1;
	CarrierRB(2:2:n,1:2:m)=-1;
	ChromiRB=filter2(filterRB,CarrierRB.*X);
	Carrier=ones(n,m);
	Carrier(1:4:n,1:2:m)=-1;
	Carrier(2:4:n,1:2:m)=-1;
	Carrier(3:4:n,2:2:m)=-1;
	Carrier(4:4:n,2:2:m)=-1;
	ChromiGM=filter2(filterGM,Carrier.*X);
	X=X-CarrierRB.*ChromiRB;
	X=X-Carrier.*ChromiGM;
	ChromiRB=ChromiRB*2.0;
	ChromiGM=ChromiGM/3.0;     
	X=X*2.0/3.0;
	
elseif (cfa==2)
	load filtersmatCondat13.mat
	I=eye(filtersize*filtersize);
	filterC=pinv(AC+(sigma*sigma*4)*I)*bC;
	filterC = reshape(filterC,filtersize,filtersize);
	
	CarrierRB=ones(n,m)*2; %/sqrt(2)
	CarrierRB(2:3:n,:)=-1;
	CarrierRB(3:3:n,:)=-1;
	CarrierRB(:,2:2:m)=-CarrierRB(:,2:2:m);
	ChromiRB=filter2(filterC,CarrierRB.*X);
	Carrier=zeros(n,m);
	Carrier(2:3:n,:)=-1; %*sqrt(3)/sqrt(2)
	Carrier(3:3:n,:)=1;
	Carrier(:,2:2:m)=-Carrier(:,2:2:m);
	ChromiGM=filter2(filterC,Carrier.*X);
	X=X-CarrierRB.*ChromiRB/2;
	X=X-Carrier.*ChromiGM*1.5;
	ChromiGM=ChromiGM/2.0;     
	X=X*2.0/3.0;
end

Y(:,:,1)=X-ChromiGM*2+ChromiRB;    
Y(:,:,2)=X+ChromiGM*4;
Y(:,:,3)=X-ChromiGM*2-ChromiRB;
