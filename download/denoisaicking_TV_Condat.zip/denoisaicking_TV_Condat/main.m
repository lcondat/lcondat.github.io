% This Matlab file is a demo for the joint demosaicking/denoising method
% described in the articles:
%
% L. Condat and S. Mosaddegh, "Joint Demosaicking and Denoising by Total Variation Minimization," 
% Proc. of IEEE ICIP, Sept. 2012, Orlando, USA. 
%
% Version 1.0, Jan. 5, 2011. 
% Tested under Windows with Matlab 7.9.0
%
% Support for the Hirakawa and Condat CFAs in addition to the Bayer CFA.
%
% This code processes the 24 Kodak images. You have to set the correct 
% path to the images on your computer so that it works. 



sigma=20;		%% noise std dev.
cfa=0;			%% 0:Bayer 1:Hirakawa 2:Condat
lambda=0.35;  	%% 0.5 for sigma=1 ; 0.45 for sigma=5; 0.4 for sigma=10; 0.35 for sigma=20
nbiter=50;		%% number of iterations
postproc=0;		%% set to 1 if you want the output image to be re-mosaicked and demosaicked 
				%% using the Zhang and Wu method. Only for cfa==0.

for ima=1:24
	%% set here the path to the images on your computer:
	name=sprintf('Z:\\lcondat-reseau\\Pictures\\couleur\\kodim%02i.tif',ima);
	I=imread(name,'tif');
	[n,m,ch]=size(I);
	if n>m		% all the images are set in landscape mode
		I=imrotate(I,90);
		[n,m,ch]=size(I);
	end
	I=double(I);
	imwrite(I/255,'original.tif');
		
	C=cfaimage(cfa,n,m);
	imwrite(C,'cfa.tif');
	M=dot(I,C,3); 	% mosaicking
	randn('state',0);
	noi=randn(n,m);
	sigma0=norm(noi(:))/sqrt(n*m);
	M=M+noi*(sigma/sigma0);
	imwrite(M/255,'mosagray.tif');
	
	J=demosa(M,cfa,sigma);	% demosaicking by frequency selection
	imwrite(J/255,'demosa_FS.tif');
	J=demosaTV(M,J,C,lambda,nbiter);
	imwrite(J/255,'demosa_TV.tif');
	
	if (sigma>0) 
		L=sum(J,3)/3.0;		% L is the luminance channel to be denoised
		J(:,:,1)=J(:,:,1)-L;
		J(:,:,2)=J(:,:,2)-L;
		J(:,:,3)=J(:,:,3)-L;
		if (cfa==0)
			[dummy,L]=BM3D(1,L/255.0,sigma);
		elseif (cfa>0)
			[dummy,L]=BM3D(1,L/255.0,sigma*2.0/3.0);
		end
		J(:,:,1)=J(:,:,1)+L*255;
		J(:,:,2)=J(:,:,2)+L*255;
		J(:,:,3)=J(:,:,3)+L*255;
	end
	
	name=sprintf('out%02i.tif',ima);
	imwrite(J/255,name);
	
	if (postproc&&(cfa==0))
		M=dot(J,C,3); % mosaicking
		J=dmsc(M);
		name=sprintf('outpostproc%02i.tif',ima);
		imwrite(J/255,name);
	end	
end
