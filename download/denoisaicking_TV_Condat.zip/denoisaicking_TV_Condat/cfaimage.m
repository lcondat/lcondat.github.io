function C = cfaimage(cfa,n,m)

C=zeros(n,m,3);

if (cfa==0)
%% mosaicking the image with the Bayer pattern 
	C(1:2:n,2:2:m,1)=1;
	C(2:2:n,1:2:m,3)=1;
	C(1:2:n,1:2:m,2)=1;
	C(2:2:n,2:2:m,2)=1;
		
elseif (cfa==1)
%% mosaicking the image with Hirakawa's 2x4 pattern
	C(1:4:n,1:2:m,1)=1;
	C(4:4:n,2:2:m,1)=1;
	C(2:4:n,1:2:m,3)=1;
	C(3:4:n,2:2:m,3)=1;
	C(1:4:n,2:2:m,2)=1;
	C(4:4:n,1:2:m,2)=1;
	C(2:4:n,2:2:m,2)=1;
	C(3:4:n,1:2:m,2)=1;
	C(1:4:n,1:m,3)=0.5;
	C(2:4:n,1:m,1)=0.5;
	C(3:4:n,1:m,1)=0.5;
	C(4:4:n,1:m,3)=0.5;
	
else
%% mosaicking the image with Condat's 2x3 pattern
	C(1:3:n,1:2:m,1)=1;
	C(1:3:n,1:2:m,2)=0.5;
	C(2:3:n,1:2:m,3)=1;
	C(2:3:n,1:2:m,1)=0.5;
	C(3:3:n,1:2:m,2)=1;
	C(3:3:n,1:2:m,3)=0.5;
	C(1:3:n,2:2:m,3)=1;
	C(1:3:n,2:2:m,2)=0.5;
	C(2:3:n,2:2:m,2)=1;
	C(2:3:n,2:2:m,1)=0.5;
	C(3:3:n,2:2:m,1)=1;
	C(3:3:n,2:2:m,3)=0.5;
end