border=20;	% A 20 pixels wide band is ignored at the boundaries of the images  
			% for the computaiton of the PSNR.

result=zeros(24,1);
for ima=1:24
	%% set here the path to the images on your computer:
	name=sprintf('Z:\\lcondat-reseau\\Pictures\\couleur\\kodim%02i.tif',ima);	
	I=imread(name,'tif');
	[n,m,ch]=size(I);
	if n>m
		I=imrotate(I,90);
		[n,m,ch]=size(I);
	end
	I=double(I);
	name=sprintf('out%02i.tif',ima);
	% name=sprintf('outpostproc%02i.tif',ima);
	J=imread(name,'tif');
	J=double(J);
	result(ima)=cpsnr(I,J,border);
end
result
mean(result)