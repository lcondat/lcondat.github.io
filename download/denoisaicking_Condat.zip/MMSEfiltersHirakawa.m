function []= MMSEfiltersHirakawa()
	border=10; %nb pixels ignored on boundaries
	%semisize=4; %patchs 9*9
	semisize=6; %patchs 13*13
	
	filtersize = 2*semisize+1;
	aux=filtersize*filtersize;
	AGM=zeros(aux,aux);
	bGM=zeros(aux,1);
	ARB=zeros(aux,aux);
	bRB=zeros(aux,1);
	total=0;
	for ima=1:24
		%% set the correct path to the set of learning images here: 
		name=sprintf('/Users/me/Pictures/kodim%02i.tif',ima);
		I=imread(name,'tif');
		[n,m,ch]=size(I);
		if n>m
			I=imrotate(I,90);
			[n,m,ch]=size(I);
		end
		I=double(I);
		ChromiGM=I(:,:,2)*(2/sqrt(6))-I(:,:,1)/sqrt(6)-I(:,:,3)/sqrt(6);
		ChromiRB=I(:,:,1)/sqrt(2)-I(:,:,3)/sqrt(2);
		
		%%mosaicking 
		Mosa=mosaick(I,1);
		
		Carrier=ones(n,m);
		Carrier(1:2:n,2:2:m)=-1;
		Carrier(2:2:n,1:2:m)=-1;
		ModulatedRB=Carrier.*Mosa*sqrt(8.0);
		Carrier=ones(n,m);
		Carrier(1:4:n,1:2:m)=-1;
		Carrier(2:4:n,1:2:m)=-1;
		Carrier(3:4:n,2:2:m)=-1;
		Carrier(4:4:n,2:2:m)=-1;
		ModulatedGM=Carrier.*Mosa*4.0/sqrt(6.0);
		
		for i=1+border:n-border
			for j=1+border:m-border
				patch=ModulatedGM(i-semisize:i+semisize,j-semisize:j+semisize);
				patch=sympart(patch);
				AGM=AGM+patch(:)*patch(:).';
				bGM=bGM+patch(:)*ChromiGM(i,j);
				patch=ModulatedRB(i-semisize:i+semisize,j-semisize:j+semisize);
				patch=sympart(patch);
				ARB=ARB+patch(:)*patch(:).';
				bRB=bRB+patch(:)*ChromiRB(i,j);
				total=total+1;
			end
		end
		ima
	end
	AGM = AGM / total;
	bGM = bGM / total;
	ARB = ARB / total;
	bRB = bRB / total;	
	name=sprintf('filtersmatHirakawa%d.mat',filtersize);
	save(name,'filtersize','AGM','bGM','ARB','bRB');
end

function [Y] = sympart(X)
	[n,m]=size(X);
	Y=(X+X(n:-1:1,:)+X(:,m:-1:1)+X(n:-1:1,m:-1:1))/4;
end