% This Matlab file is a demo for the joint demosaicking/denoising method
% described in the articles:
%
% L Condat, "A Simple, Fast and Efficient Approach to Denoisaicking: 
% Joint Demosaicking and Denoising", IEEE ICIP, Hong-Kong, China, 2010.
%
% L. Condat,  "A new color filter array with optimal properties for 
% noiseless and noisy color image acquisition," to appear in IEEE Trans. Image Proc.
%
% This code processes the 24 Kodak images. You have to set the correct 
% path to the images on your computer so that it works. 



sigma=20;   % noise std dev.

cfa=0;		% 0:Bayer 1:Hirakawa 2:Condat

postproc=1; % set to 1 to re-mosaick the denoisaicked image and then demosaick it 
% using your favorite demosaicking method


% this loop processes the 24 Kodak images
for ima=1:24
	%% set here the path to the images on your computer:
	%name=sprintf('/Users/lcondat/Pictures/kodim%02i.tif',ima);
	%% Windows version:
	%name=sprintf('C:\\Pictures\\kodim%02i.tif',ima);
	I=imread(name,'tif');
	[n,m,ch]=size(I);
	if n>m
		I=imrotate(I,90);
		[n,m,ch]=size(I);
	end
	I=double(I);
	
	M=mosaick(I,cfa);
	randn('state',0);
	noi=randn(n,m);
	sigma0=norm(noi(:))/sqrt(n*m);	% Minor change added in version 2.0. 
	M=M+noi*(sigma/sigma0);
	%% save the noisaicked image
	imwrite(M/255,'mosagray.tif');
	
	J=denoisaick(M,cfa,sigma);
	name=sprintf('out%02i.tif',ima);
	imwrite(J/255,name);
		
	if (postproc&&(cfa==0))
		%% re-mosaicking
		I=mosaick(J,0);
		J=dmsc(I);
		name=sprintf('outpostproc%02i.tif',ima);
		imwrite(J/255,name);
	end
end
