These Matlab files implement the joint demosaicking/denoising method for images acquired with the Bayer CFA, the Hirakawa CFA or the Condat CFA, as described in the articles:

L. Condat, "A Simple, Fast and Efficient Approach to Denoisaicking: Joint Demosaicking and Denoising", IEEE ICIP, Hong-Kong, China, 2010.

L. Condat,  "A new color filter array with optimal properties for noiseless and noisy color image acquisition," to appear in IEEE Trans. Image proc. 

Files written by Laurent Condat, CNRS research fellow in the Image team of the GREYC lab, a joint CNRS-UCBN-ENSICAEN research unit.
For any comment, don't hesitate to e-mail me: laurent.condat@greyc.ensicaen.fr

Version 3.0, Feb. 22, 2011. New in v.3.0: mexfiles from the BM3D package v1.7.6 added. 
Tested under Windows. Although BM3D mexfiles for Intel Mac are provided, the BM3D code gives an error on my Mac.

The main.m file is a demo processing the 24 Kodak images. You have to set the correct path to the Kodak images on your computer so that it works. 

The Wiener-like filters for estimating the denoised chrominance are solutions of linear systems. They are computed during the denoisaicking process, because they depend on the noise level sigma. 
The corresponding .mat files can be re-generated using the programs MMSEfiltersXXX.m, but be patient, the process is very slow!

Any denoising method can be used but we provide as example the code implementing the BM3D denoising method described in the article
K. Dabov, A. Foi, V. Katkovnik, and K. Egiazarian, "Image denoising by sparse 3D transform-domain collaborative filtering," IEEE Trans. Image Process., vol. 16, no. 8, August 2007.
See the LEGAL_NOTICE.txt for property rights of the BM3D code.