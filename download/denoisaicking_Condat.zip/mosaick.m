function [M] = mosaick(I,cfa)

[n,m,ch]=size(I);

if (cfa==0)
%% mosaicking the image with the Bayer pattern 
% G R
% B G
	M(1:n,1:m)=I(:,:,2);
	M(1:2:n,2:2:m)=I(1:2:n,2:2:m,1);
	M(2:2:n,1:2:m)=I(2:2:n,1:2:m,3);
	
elseif (cfa==1)
%% mosaicking the image with Hirakawa's 2x4 pattern
	M(1:n,1:m)=I(:,:,2);
	M(1:4:n,1:2:m)=I(1:4:n,1:2:m,1);
	M(4:4:n,2:2:m)=I(4:4:n,2:2:m,1);
	M(2:4:n,1:2:m)=I(2:4:n,1:2:m,3);
	M(3:4:n,2:2:m)=I(3:4:n,2:2:m,3);
	M(1:4:n,1:m)=M(1:4:n,1:m)+I(1:4:n,1:m,3)/2.0;
	M(2:4:n,1:m)=M(2:4:n,1:m)+I(2:4:n,1:m,1)/2.0;
	M(3:4:n,1:m)=M(3:4:n,1:m)+I(3:4:n,1:m,1)/2.0;
	M(4:4:n,1:m)=M(4:4:n,1:m)+I(4:4:n,1:m,3)/2.0;
else
%% mosaicking the image with Condat's 2x3 pattern
	M(1:3:n,1:2:m)=I(1:3:n,1:2:m,1)+I(1:3:n,1:2:m,2)/2.0;
	M(2:3:n,1:2:m)=I(2:3:n,1:2:m,3)+I(2:3:n,1:2:m,1)/2.0;
	M(3:3:n,1:2:m)=I(3:3:n,1:2:m,2)+I(3:3:n,1:2:m,3)/2.0;
	M(1:3:n,2:2:m)=I(1:3:n,2:2:m,3)+I(1:3:n,2:2:m,2)/2.0;
	M(2:3:n,2:2:m)=I(2:3:n,2:2:m,2)+I(2:3:n,2:2:m,1)/2.0;
	M(3:3:n,2:2:m)=I(3:3:n,2:2:m,1)+I(3:3:n,2:2:m,3)/2.0;
end