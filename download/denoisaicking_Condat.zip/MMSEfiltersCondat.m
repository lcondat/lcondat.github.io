function []= MMSEfiltersCondat()
	border=10; %nb pixels ignored on boundaries
	%semisize=4; %patchs 9*9
	semisize=6; %patchs 13*13
	
	filtersize = 2*semisize+1;
	aux=filtersize*filtersize;
	AC=zeros(aux,aux);
	bC=zeros(aux,1);
	total=0;
	for ima=1:24
		%% set the correct path to the set of learning images here: 
		name=sprintf('/Users/me/Pictures/kodim%02i.tif',ima);
		I=imread(name,'tif');
		[n,m,ch]=size(I);
		if n>m
			I=imrotate(I,90);
			[n,m,ch]=size(I);
		end
		I=double(I);
		ChromiGM=I(:,:,2)*(2/sqrt(6))-I(:,:,1)/sqrt(6)-I(:,:,3)/sqrt(6);
		ChromiRB=I(:,:,1)/sqrt(2)-I(:,:,3)/sqrt(2);
		
		%%mosaicking 
		Mosa=mosaick(I,2);
		
		Carrier=ones(n,m)*2;
		Carrier(2:3:n,:)=-1;
		Carrier(3:3:n,:)=-1;
		Carrier(:,2:2:m)=-Carrier(:,2:2:m);
		ModulatedRB=Carrier.*Mosa*sqrt(2.0);
		Carrier=zeros(n,m);
		Carrier(2:3:n,:)=-1;
		Carrier(3:3:n,:)=1;
		Carrier(:,2:2:m)=-Carrier(:,2:2:m);
		ModulatedGM=Carrier.*Mosa*sqrt(6.0);
		
		for i=1+border:n-border
			for j=1+border:m-border
				patch=ModulatedGM(i-semisize:i+semisize,j-semisize:j+semisize);
				patch=sympart(patch);
				AC=AC+patch(:)*patch(:).';
				bC=bC+patch(:)*ChromiGM(i,j);
				patch=ModulatedRB(i-semisize:i+semisize,j-semisize:j+semisize);
				patch=sympart(patch);
				AC=AC+patch(:)*patch(:).';
				bC=bC+patch(:)*ChromiRB(i,j);
				total=total+2;
			end
		end
		ima
	end
	AC = AC / total;
	bC = bC / total;
	name=sprintf('filtersmatCondat%d.mat',filtersize);
	save(name,'filtersize','AC','bC');
end

function [Y] = sympart(X)
	[n,m]=size(X);
	Y=(X+X(n:-1:1,:)+X(:,m:-1:1)+X(n:-1:1,m:-1:1))/4;
end