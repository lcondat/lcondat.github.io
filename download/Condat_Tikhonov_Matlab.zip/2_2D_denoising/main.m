function main()

    lambda = 5; %regularization parameter
    nbiter = 450; %number of iterations
    tau = 0.1; %parameter of the algorithm, >0
    rho = 1; %parameter of the algorithm, in [1,2)

    y = [1.0, 2.0, 4.0, 1.0;
    6.0, 3.0, 5.0, 2.0;
    4.0, 2.0, 1.0, 5.0;
    5.0, 4.0, 2.0, 3.0];
    y = interp2(y,5,'cubic');
    y0 = mod((y-1)/5*2,1)*(2*pi)-pi;
    figure(1)
    imshow(y0,[-pi,pi])
    colorcet('C2');
    colorbar
    truesize(size(y)*3);
   
    rng(1);
    y = y0 + randn(size(y0))*0.5;
    y = angle(exp(1i*y));
    figure(2)
    imshow(y,[-pi,pi])
    colorcet('C2');
    colorbar
    truesize(size(y)*3);
    
    y = exp(1i*y);

    x2 = restore2(y,lambda,500);
    figure(3)
    imshow(angle(x2),[-pi,pi])
    colorcet('C2');
    colorbar
    truesize(size(y)*3);
    drawnow
    fprintf("\n");

    x = restore(y,lambda,nbiter,tau,rho);
    figure(4)
    imshow(angle(x),[-pi,pi])
    colorcet('C2');
    colorbar 
    truesize(size(y)*3);
end


function x = restore(y,lambda,nbiter,tau,rho)
    [N1,N2] = size(y);
    x = y;
    r1 = y(1:end-1,:).*conj(y(2:end,:));
    r2 = y(:,1:end-1).*conj(y(:,2:end));
    U1 = zeros(3,3,N1-1,N2);
    U2 = zeros(3,3,N1,N2-1);
    Id1 = zeros(3,3,N1-1,N2);
    Id2 = zeros(3,3,N1,N2-1);
    Id1(1,1,:,:)=1;
    Id1(2,2,:,:)=1;
    Id1(3,3,:,:)=1;
    Id2(1,1,:,:)=1;
    Id2(2,2,:,:)=1;
    Id2(3,3,:,:)=1;
    sigma = 1/tau/8;
    for i = 1:nbiter
        [ax,ar1,ar2] = opLadj(U1,U2);
        ax = ax - y;
        ar1 = ar1 - lambda;
        ar2 = ar2 - lambda;
        [V1,V2] = opL(x-(2*tau)*ax,r1-(2*tau)*ar1,r2-(2*tau)*ar2);
        [V1,V2] = prox(U1+sigma*(V1+Id1),U2+sigma*(V2+Id2));
        U1 = U1 + rho*(V1-U1);
        U2 = U2 + rho*(V2-U2);
        x = x - (rho*tau)*ax;
        r1 = r1 - (rho*tau)*ar1;
        r2 = r2 - (rho*tau)*ar2;
        
        if mod(i,50)==0, 
            % we display: iteration number, primal cost, dual cost, 
            % nonconvex cost on rescaled x, min_n |x_n|, max_(n,n') |r_{n,n'}-x_n.x_{n,n'}^*|
            fprintf("%d %f %f %f %f %f\n",i,...
                sum(1-x(:).*conj(y(:)))+lambda*sum(1-real(r1(:)))+lambda*sum(1-real(r2(:))),...
                N1*N2+lambda*((N1-1)*N2+(N2-1)*N1)+sum(diag(sum(sum(U1,4),3)))+...
                sum(diag(sum(sum(U2,4),3))),...
                sum(1-cos(angle(x(:))-angle(y(:))))+...
                lambda*sum(sum(1-cos(angle(x(1:end-1,:))-angle(x(2:end,:)))))+...
                lambda*sum(sum(1-cos(angle(x(:,1:end-1))-angle(x(:,2:end))))),...
                min(abs(x(:))),...
                max(max(max(abs(r1-x(1:end-1,:).*conj(x(2:end,:))))),...
                max(max(abs(r2-x(:,1:end-1).*conj(x(:,2:end)))))));
            figure(4)
            imshow(angle(x),[-pi,pi])
            colorcet('C2');
            colorbar 
            truesize(size(y)*3);
            drawnow
        end
    end
end

function [U1,U2] = opL(x,r1,r2)
    [N1,N2] = size(x);
    U1 = zeros(3,3,N1-1,N2);
    U1(2,1,:,:) = x(1:end-1,:);
    U1(1,2,:,:) = conj(x(1:end-1,:));
    U1(3,1,:,:) = x(2:end,:);
    U1(1,3,:,:) = conj(x(2:end,:));
    U1(2,3,:,:) = r1;
    U1(3,2,:,:) = conj(r1);
    U2 = zeros(3,3,N1,N2-1);
    U2(2,1,:,:) = x(:,1:end-1);
    U2(1,2,:,:) = conj(x(:,1:end-1));
    U2(3,1,:,:) = x(:,2:end);
    U2(1,3,:,:) = conj(x(:,2:end));
    U2(2,3,:,:) = r2;
    U2(3,2,:,:) = conj(r2);
end

function [x,r1,r2] = opLadj(U1,U2)
    N1 = size(U1,3)+1;
    N2 = size(U1,4);
    x = zeros(N1,N2);
    x(1:end-1,:) = U1(2,1,:,:) + conj(U1(1,2,:,:));
    x(2:end,:) = x(2:end,:) + squeeze(U1(3,1,:,:) + conj(U1(1,3,:,:)));
    x(:,1:end-1) = x(:,1:end-1) + squeeze(U2(2,1,:,:) + conj(U2(1,2,:,:)));
    x(:,2:end) = x(:,2:end) + squeeze(U2(3,1,:,:) + conj(U2(1,3,:,:)));
    r1 = squeeze(U1(2,3,:,:) + conj(U1(3,2,:,:)));
    r2 = squeeze(U2(2,3,:,:) + conj(U2(3,2,:,:)));
end

function [Uout1,Uout2] = prox(U1,U2)
    N1 = size(U1,3)+1;
    N2 = size(U1,4);
    Uout1 = U1;
    Uout2 = U2;
    for n1 = 1:N1-1
        for n2 = 1:N2
            [V,D] = eig(Uout1(:,:,n1,n2));
            Uout1(:,:,n1,n2) = V*min(real(D),0)*V';
        end
    end
    for n1 = 1:N1
        for n2 = 1:N2-1
            [V,D] = eig(Uout2(:,:,n1,n2));
            Uout2(:,:,n1,n2) = V*min(real(D),0)*V';
        end
    end
end

%Richarson iteration to solve the positive definite linear system
function x = restore2(y,lambda,nbiter)
    x = y;
    for i = 1:nbiter
        d = diff(x,1,1);
        d2 = diff(x,1,2);
        x = x + 1.9*(y-(x+lambda*([-d(1,:);-diff(d,1,1);d(end,:)]+[-d2(:,1) -diff(d2,1,2) d2(:,end)])))/(8*lambda+1);
        if mod(i,100)==0, 
            % we display: iteration number, nonconvex cost on rescaled x
            fprintf("%d %f\n",i,sum(1-cos(angle(x(:))-angle(y(:))))+...
                lambda*sum(sum(1-cos(angle(x(1:end-1,:))-angle(x(2:end,:)))))+...
                lambda*sum(sum(1-cos(angle(x(:,1:end-1))-angle(x(:,2:end))))));
        end
    end
end
