function main()

	N = 10;	%signal length

	nbiter = 60000; %number of iterations
	tau = 1; %parameter of the algorithm, >0
	rho = 1; %parameter of the algorithm, in [1,2)

	y = zeros(N,1);
	y(1) = -1;
	y(N) = 2;
	y = exp(1i*y);
	
	x0 = restore2(y,400);
	hold off
	plot(angle(x0),'*--b','linewidth',2);
	ylim([-pi pi]);
	drawnow
	fprintf("\n");
	
	x = restore(y,nbiter,tau,rho);
	hold on
	plot(angle(x),'*--r','linewidth',2);
	%plot(1:10,angle(((1:10)-1)/9*exp(2i)+(10-(1:10))/9*exp(-1i)),'g')
end


function x = restore(y,nbiter,tau,rho)
	N = length(y);
	x = y;
	r = y(1:end-1).*conj(y(2:end));
	U = zeros(3,3,N-1);
	Id = zeros(3,3,N-1);
	Id(1,1,:)=1;
	Id(2,2,:)=1;
	Id(3,3,:)=1;
	sigma = 1/tau/4;
	for i = 1:nbiter
		[ax,ar] = opLadj(U,N);
		xx = x - tau*ax;
		rr = r - tau*ar + 1;
		xx(1) = y(1);
		xx(end) = y(end);
		U = prox(U+sigma*(opL(2*xx-x,2*rr-r,N)+Id),N);
		x = xx;
		r = rr;
		if mod(i,1000)==0, 
			fprintf("%d %f %f %f %f\n",i,sum(1-real(r)),...
				sum(1-cos(angle(x(1:end-1))-angle(x(2:end)))),...
				min(abs(x)),max(abs(r-x(1:end-1).*conj(x(2:end))))); 
		end
	end
end

function U = opL(x,r,N)
	U = zeros(3,3,N-1);
	U(2,1,:) = x(1:end-1);
	U(1,2,:) = conj(x(1:end-1));
	U(3,1,:) = x(2:end);
	U(1,3,:) = conj(x(2:end));
	U(2,3,:) = r;
	U(3,2,:) = conj(r);
end

function [x,r] = opLadj(U,N)
	x = zeros(N,1);
	x(1:end-1) = U(2,1,:) + conj(U(1,2,:));
	x(2:end) = x(2:end) + squeeze(U(3,1,:) + conj(U(1,3,:)));
	r = squeeze(U(2,3,:) + conj(U(3,2,:)));
end

function Uout = prox(U,N)
	Uout = U;
	for n = 1:N-1
		[V,D] = eig(Uout(:,:,n));
		Uout(:,:,n) = V*min(real(D),0)*V';
	end
end

%projected gradient descent
function x = restore2(y,nbiter)
	x = y;
	for i = 1:nbiter
		d = diff(x);
		x = x - (1.9/4)*[-d(1);-diff(d);d(end)];
		x(1) = y(1);
		x(end) = y(end);
		if mod(i,100)==0
			% we display: iteration number, nonconvex cost on rescaled x
			fprintf("%d %f\n",i,sum(1-cos(angle(x(1:end-1))-angle(x(2:end)))));
		end
	end
end



