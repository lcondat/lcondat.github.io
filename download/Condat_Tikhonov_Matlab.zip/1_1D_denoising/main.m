function main()

	N = 1000;	%signal length
	lambda = 50; %regularization parameter

	nbiter = 300; %number of iterations
	tau = 0.1; %parameter of the algorithm, >0
	rho = 1; %parameter of the algorithm, in [1,2)

	rng(0);
	y0 = zeros(N,1);
	y0(1) = 10;
	for n = 2:N
		y0(n)=y0(n-1)+randn(1,1);
	end
	y = y0 + randn(N,1)*sqrt(lambda);
	y0=exp(1i*y0/10);
	y=exp(1i*y/10);
	
	
	%figure(1);
	%hold off
	%plot(angle(y0),'Color',green,'linewidth',2);
	%hold on
	%plot(angle(y),'k');
	%ylim([-pi pi]);

	x0 = restore2(y,lambda,1000);
	green = [0 0.85 0];
	fprintf("\n");
	hold off
	plot(angle(y0),'Color',green,'linewidth',2);
	hold on
	plot(angle(y),'k');
	ylim([-pi pi]);
	plot(angle(x0),'b','linewidth',2);
	drawnow
	
	x = restore(y,lambda,nbiter,tau,rho);
	hold off
	plot(angle(y0),'Color',green,'linewidth',2);
	hold on
	plot(angle(y),'k');
	plot(angle(x0),'b','linewidth',2);
	ylim([-pi pi]);
	plot(angle(x),'r','linewidth',2);
end


function x = restore(y,lambda,nbiter,tau,rho)
	N = length(y);
	x = y;
	r = y(1:end-1).*conj(y(2:end));
	U = zeros(3,3,N-1);
	%U(2,3,:)=lambda/2;
	%U(3,2,:)=lambda/2;
	Id = zeros(3,3,N-1);
	Id(1,1,:)=1;
	Id(2,2,:)=1;
	Id(3,3,:)=1;
	sigma = 1/tau/4;
	for i = 1:nbiter
		[ax,ar] = opLadj(U,N);
		ax = ax - y;
		ar = ar - lambda;
		U = U + rho*(prox(U+sigma*(opL(x-(2*tau)*ax,r-(2*tau)*ar,N)+Id),N)-U);
		x = x - (rho*tau)*ax;
		r = r - (rho*tau)*ar;

		if mod(i,50)==0, 
			%plot(angle(x),'r');
			%drawnow
			% we display: iteration number, primal cost, dual cost, 
			% nonconvex cost on rescaled x, min_n |x_n|, max_n |r_{n,n+1}-x_n.x_{n+1}^*|
			fprintf("%d %f %f %f %f %f\n",i,sum(1-x.*conj(y))+lambda*sum(1-real(r)),...
				N+lambda*(N-1)+sum(diag(sum(U,3))),...
				sum(1-cos(angle(x)-angle(y)))+lambda*sum(1-cos(angle(x(1:end-1))-angle(x(2:end)))),...
				min(abs(x)),max(abs(r-x(1:end-1).*conj(x(2:end))))); 
		end
	end
end

function U = opL(x,r,N)
	U = zeros(3,3,N-1);
	U(2,1,:) = x(1:end-1);
	U(1,2,:) = conj(x(1:end-1));
	U(3,1,:) = x(2:end);
	U(1,3,:) = conj(x(2:end));
	U(2,3,:) = r;
	U(3,2,:) = conj(r);
end

function [x,r] = opLadj(U,N)
	x = zeros(N,1);
	x(1:end-1) = U(2,1,:) + conj(U(1,2,:));
	x(2:end) = x(2:end) + squeeze(U(3,1,:) + conj(U(1,3,:)));
	r = squeeze(U(2,3,:) + conj(U(3,2,:)));
end

function Uout = prox(U,N)
	Uout = U;
	for n = 1:N-1
		[V,D] = eig(Uout(:,:,n));
		Uout(:,:,n) = V*min(real(D),0)*V';
	end
end

%Richarson iteration to solve the positive definite linear system
% (Id+lambda.D^*D)x = y
function x = restore2(y,lambda,nbiter)
	x = y;
	for i = 1:nbiter
		d = diff(x);
		x = x + 1.9*(y-(x+lambda*[-d(1);-diff(d);d(end)]))/(4*lambda+1);
		if mod(i,100)==0
			% we display: iteration number, nonconvex cost on rescaled x
			fprintf("%d %f\n",i,sum(1-cos(angle(x)-angle(y)))+lambda*sum(1-cos(angle(x(1:end-1))-angle(x(2:end)))));
		end
	end
end



