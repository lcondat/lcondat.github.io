% convex relaxation of the K-means problem

% min <z,c> s.t. columns of z on the simplex and sum_rows(max_columns(z))<=K

% The l1,infinity constraint is split

% Author: Laurent Condat, PhD, https://lcondat.github.io/
% Nov. 26, 2020
% Copyright: Laurent Condat.

% If you use this code, please cite the paper:
% L. Condat, “A Convex Approach to K-means Clustering and Image Segmentation,” EMMCVPR, Oct. 2017, Venice, Italy. 
% In: M. Pelillo and E. Hancock eds., Lecture Notes in Computer Science vol. 10746, Springer, pp. 220-234, 2018.  


function main
	K = 20; 
	nbiter = 3000; 
	tau = 1000; 
	mu = 0.5;	
	sigma = 1/tau/(1+1/mu);
	rho = 1.9;	
 	
	N=3000;
	y=importdata('a1.txt');
	figure(1)
	hold off
	scatter(y(:,1),y(:,2),10,'r','filled');
	axis equal
	rng default;
	hold on
	colorbar
	ylim([min(y(:,2)),max(y(:,2))])
	xlim([min(y(:,1)),max(y(:,1))])

	Mx = 80;
	My = 40;
	M = Mx*My;
 	[cx,cy]=meshgrid((0:Mx-1)/(Mx-1)*(max(y(:,1))-min(y(:,1)))+min(y(:,1)),...
 		(0:My-1)/(My-1)*(max(y(:,2))-min(y(:,2)))+min(y(:,2)));
 	candidates = reshape([cx(:),cy(:)],M,2);
 	idx = find(inhull(candidates,y));
	candidates = candidates(idx,:);
	M = size(candidates,1)	
	candidates = reshape(candidates,M,1,2);
 		
 	sqrtN = sqrt(N*mu);
	proj_simplex = @(z) max(bsxfun(@minus,z,max(bsxfun(@rdivide,...
 		cumsum(sort(z,1,'descend'),1)-1,(1:M)'))),0);
 	proj_lec = @(q,a) q-max(sum(q)-a,0)/length(q);  %make the sum of q <= a
 	opL = @(z,q) bsxfun(@minus, z, q/sqrtN); 
 	c = sum(bsxfun(@minus, shiftdim(y,-1),candidates).^2,3);
	c = c/max(c(:))*2; %heuristic scaling
	[tmp, idx] = min(c);
    z = double(bsxfun(@eq, (1:M)', idx));	
    u = zeros(size(z));
	q = zeros(M,1); %auxiliary vector used to split the max
	
	iter = 0;	
	while 1
		iter=iter+1;
		znew = proj_simplex(z - tau*(u+c));
		qnew = proj_lec(q + tau*sum(u,2)/sqrtN,sqrtN*K);
		unew = max(u + sigma*opL(2*znew-z,2*qnew-q),0);
    	z = z + rho*(znew - z);
    	q = q + rho*(qnew - q);
    	u = u + rho*(unew - u);
		if mod(iter,10)==0
			val1 = sum(max(znew,[],2)); % feasibility test
			val2 = sum(sum(znew.*c)); 	% primal cost value
			val3 = sum(min(unew+c))-K*mean(sum(unew,2)); %dual cost value
			fprintf('%d %.2g %.2f %f %f %.2g\n',iter,val1-K,...
				min(max(znew)),val2,val3,val2-val3);
			%x = shiftdim(sum(bsxfun(@times,znew,candidates),1),1);
			%figure(3)
			%imshow(x/255);
			scatter(candidates(:,1,1),candidates(:,1,2),15,max(znew,[],2),'filled');
			drawnow
			%if (val1-K<1e-2)&&(abs(val2-val3)<1e-2), break; end
			if iter==nbiter, break; end
		end
	end
		
	zbin = double(bsxfun(@eq,znew,max(znew)));
	fprintf('\n%f %g %f\n',sum(sum(zbin.*c)),sum(sum(zbin.*c))-val2,sum(max(zbin,[],2)));
	%x = shiftdim(sum(bsxfun(@times,zbin,candidates)),1);
	figure(2)
	scatter(y(:,1),y(:,2),10,'r','filled');
	axis equal
	hold on
	scatter(candidates(:,1,1),candidates(:,1,2),15,max(zbin,[],2),'filled');
end

