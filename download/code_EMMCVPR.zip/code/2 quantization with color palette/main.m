% convex relaxation of color image quantization

% min <z,c> s.t. columns of z on the simplex and sum_rows(max_columns(z))<=K

% Author: Laurent Condat, PhD, https://lcondat.github.io/
% Nov. 26, 2020
% Copyright: Laurent Condat.

% If you use this code, please cite the paper:
% L. Condat, “A Convex Approach to K-means Clustering and Image Segmentation,” EMMCVPR, Oct. 2017, Venice, Italy. 
% In: M. Pelillo and E. Hancock eds., Lecture Notes in Computer Science vol. 10746, Springer, pp. 220-234, 2018.  

% Here the l1,infinity constraint is split

function main
	K = 5; % number of colors
	nbiter = 4000; 
	tau = 400;
	mu = 3;
	sigma = 1/tau/(1+1/mu);
	rho = 1.9;		
 	
 	load('palette279.mat');
 	M = size(palette,1); % number of candidates
 	palette = palette/255;
 	 	
	%y = double(imread('tournesol2.tif'));
	%y = double(imread('cocci2.tif'));
	y = double(imread('parrot2.tif'));
	[height,width,nbcol] = size(y);
	N = width*height; % number of pixels
	sqrtN = sqrt(N*mu);
	figure(1)
	imshow(y/255);
	
	proj_simplex = @(z) max(bsxfun(@minus,z,max(bsxfun(@rdivide,...
 		cumsum(sort(z,1,'descend'),1)-1,(1:M)'))),0);
 	proj_lec = @(q,a) q-max(sum(q)-a,0)/length(q);  %make the sum of q <= a
 	opL = @(z,q) bsxfun(@minus, z, q/sqrtN); 
 	c = sum(bsxfun(@minus, shiftdim(rgb2lab(y/255),-1),reshape(rgb2lab(palette),M,1,1,3)).^2,4);
	cmax = max(c(:))/2;
	c = c/cmax; %heuristic scaling
	[tmp, idx] = min(c);
    z = double(bsxfun(@eq, (1:M)', idx));	
	x = shiftdim(sum(bsxfun(@times,z,reshape(palette,M,1,1,3)),1),1);
	figure(2)
	imshow(x);
	
	u = zeros(size(z));
	q = zeros(M,1); %auxiliary vector used to split the max
	
	iter = 0;	
	val4 = 0;
	while 1
		iter=iter+1;
		znew = proj_simplex(z - tau*(u+c));
		qnew = proj_lec(q + (tau/sqrtN)*sum(sum(u,3),2),sqrtN*K);
		unew = max(u + sigma*opL(znew+(znew-z),qnew+(qnew-q)),0);
    	z = z + rho*(znew - z);
    	q = q + rho*(qnew - q);
    	u = u + rho*(unew - u);
		if mod(iter,10)==0
			val1 = sum(max(max(znew,[],3),[],2)); % feasibility test
			val2 = sum(sum(sum(znew.*c))); 	% primal cost value
			val3 = sum(sum(min(unew+c)))-K*max(sum(sum(unew,3),2)); %dual cost value
			if val3>val4, val4=val3; end
			fprintf('%d %.2g %.2f %f %f %f %.2g\n',iter,val1-K,...
				min(min(max(znew))),val2,val3,val4,val2-val4);
			x = shiftdim(sum(bsxfun(@times,znew,reshape(palette,M,1,1,3)),1),1);
			figure(3)
			imshow(x);
			drawnow
			if iter==nbiter, break; end
		end
	end
	x = shiftdim(sum(bsxfun(@times,znew,reshape(palette,M,1,1,3))),1);
	figure(3)
	imshow(x);
	imwrite(x,'x.tif');
	
	zbin = double(bsxfun(@eq,znew,max(znew)));
	fprintf('\n%f %g %f\n',sum(sum(sum(zbin.*c))),sum(sum(sum(zbin.*c)))-val2,sum(max(max(zbin,[],3),[],2)));
	x = shiftdim(sum(bsxfun(@times,zbin,reshape(palette,M,1,1,3))),1);
	figure(4)
	imshow(x);
	imwrite(x,'xbin.tif');
	
	% postprocessing
	idx=find(max(max(zbin,[],3),[],2)==1);
	ylab=rgb2lab(reshape(y,N,3)/255);
	if length(idx)==K 
		palette2 = rgb2lab(palette(idx,:));
		rng default;
		[idx,cl] = kmeans(ylab,K,'Start',palette2);
		sum(sum((ylab-cl(idx,:)).^2))/cmax
		cl = lab2rgb(cl);
		xpost = reshape(cl(idx,:),height,width,3);
		figure(5); imshow(xpost);
		imwrite(xpost,'xpost.tif');
	end
	rng default;
	[idx,cl] = kmeans(ylab,K);
	sum(sum((ylab-cl(idx,:)).^2))/cmax
	cl = lab2rgb(cl);
	xkmeans = reshape(cl(idx,:),height,width,3);
	figure(6); imshow(xkmeans);
	imwrite(xkmeans,'xkmeans1.tif');
end

