% convex relaxation of the K-means problem, with the set of
% candidates for the centroids equal to the set of data points.
% So, this is the K-medoids problem.

% We look for the assignment matrix z with its columns on the 
% simplex and sum_rows(max_columns(z))<=K, minimizing
% <z,c>, where c_{m,n} = ||y_n-y_m||_2^2

% The l1,infinity constraint is split

% Author: Laurent Condat, PhD, https://lcondat.github.io/
% Nov. 26, 2020
% Copyright: Laurent Condat.

% If you use this code, please cite the paper:
% L. Condat, “A Convex Approach to K-means Clustering and Image Segmentation,” EMMCVPR, Oct. 2017, Venice, Italy. 
% In: M. Pelillo and E. Hancock eds., Lecture Notes in Computer Science vol. 10746, Springer, pp. 220-234, 2018.  



function main
	K = 20;  		% number of clusters
	nbiter = 4000; 	% number of iterations
	tau = 1000; %1200 pour 1 point sur 5
	mu = 0.5;	%0.2 pour 1 point sur 5
	sigma = 1/tau/(1+1/mu);
	rho = 1.9;		
 	
	y = importdata('a1.txt');
	%N = 3000;		% number of data points
	%y = y(1:5:end,:); % 1 point sur 5
	N = size(y,1);
	
	figure(1)
	scatter(y(:,1),y(:,2),10,'r','filled');
	axis equal
	rng default;
	hold on
	colorbar
	ylim([min(y(:,2)),max(y(:,2))])
	xlim([min(y(:,1)),max(y(:,1))])
	colormap cool
	
	M = N; 		% number of candidates
	sqrtN = sqrt(N*mu);
 	candidates = reshape(y,M,1,2);
	
	proj_simplex = @(z) max(bsxfun(@minus,z,max(bsxfun(@rdivide,...
 		cumsum(sort(z,1,'descend'),1)-1,(1:M)'))),0);
 	proj_lec = @(q,a) q-max(sum(q)-a,0)/length(q);  %make the sum of q <= a
 	opL = @(z,q) bsxfun(@minus, z, q/sqrtN); 
 	
 	c = sum(bsxfun(@minus, shiftdim(y,-1),candidates).^2,3);
	c = c/max(c(:))*2;
	z = eye(M);		% initial estimate: the identity    
    u = zeros(M);
	q = zeros(M,1); % auxiliary vector reprensenting the max. over the rows
	
	for iter = 1:nbiter	
		znew = proj_simplex(z - tau*(u+c));
		qnew = proj_lec(q + (tau/sqrtN)*sum(u,2),sqrtN*K);
		unew = max(u + sigma*opL(2*znew-z,2*qnew-q),0); 
    	z = z + rho*(znew - z);
    	q = q + rho*(qnew - q);
    	u = u + rho*(unew - u); 
		if mod(iter,10)==0
			val1 = sum(max(znew,[],2)); % feasibility test
			val2 = sum(sum(znew.*c)); 	% primal cost value
			val3 = sum(min(unew+c))-K*mean(sum(unew,2)); %dual cost value
			fprintf('%d %f %f %f %f %.2g\n',iter,val1,...
				min(max(znew)),val2,val3,val2-val3);
			tmp = max(znew,[],2);
			scatter(candidates(:,1,1),candidates(:,1,2),15,tmp,'filled');
			idx = find(tmp>0.5);
			scatter(candidates(idx,1,1),candidates(idx,1,2),15,tmp(idx),'filled');
			drawnow
		end
	end
end
