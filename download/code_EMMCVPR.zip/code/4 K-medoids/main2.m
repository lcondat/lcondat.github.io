% convex relaxation of the K-means problem, with the set of
% candidates for the centroids equal to the set of data points.
% So, this is the K-medoids problem.

% We look for the assignment matrix z with its columns on the 
% simplex and sum_rows(max_columns(z))<=K, minimizing
% <z,c>, where c_{m,n} = ||y_n-y_m||_2^2

% We use the Douglas-Rachford splitting algorithm

% Author: Laurent Condat, PhD, https://lcondat.github.io/
% Nov. 26, 2020
% Copyright: Laurent Condat.

% If you use this code, please cite the paper:
% L. Condat, “A Convex Approach to K-means Clustering and Image Segmentation,” EMMCVPR, Oct. 2017, Venice, Italy. 
% In: M. Pelillo and E. Hancock eds., Lecture Notes in Computer Science vol. 10746, Springer, pp. 220-234, 2018.  


function main
	K = 20;  		% number of clusters
	nbiter = 2000; 	% number of iterations
	tau = 3500; 
	sigma = 1/tau;
	rho = 1.9;		
 	
	y = importdata('a1.txt');
	N = size(y,1);
	
	figure(1)
	scatter(y(:,1),y(:,2),10,'r','filled');
	axis equal
	rng default;
	hold on
	colorbar
	ylim([min(y(:,2)),max(y(:,2))])
	xlim([min(y(:,1)),max(y(:,1))])
	colormap cool
	
	M = N; 		% number of candidates
 	candidates = reshape(y,M,1,2);

	proj_simplex = @(z) max(bsxfun(@minus,z,max(bsxfun(@rdivide,...
 		cumsum(sort(z,1,'descend'),1)-1,(1:M)'))),0);
 	prox_sigma_g_conj = @(u) u-projl1inf(u,sigma*K);
	z = eye(M);
	c = sum(bsxfun(@minus, shiftdim(y,-1),candidates).^2,3);
	c = c/max(c(:));
	u = zeros(M);
	
	for iter = 1:nbiter		
		znew = proj_simplex(z - tau*(u+c));
		unew = prox_sigma_g_conj(u + sigma*(2*znew-z));
    	z = znew + (rho-1)*(znew - z);
    	u = unew + (rho-1)*(unew - u);
		
		if mod(iter,5)==0
			val1 = sum(max(znew,[],2)); % feasibility test
			val2 = sum(sum(znew.*c)); 	% primal cost value
			val3 = sum(min(unew+c))-K*max(sum(unew,2)); %dual cost value
			fprintf('%d %f %f %f %f %.2g\n',iter,val1,...
				min(max(znew)),val2,val3,val2-val3);
			tmp = max(znew,[],2);
			scatter(candidates(:,1,1),candidates(:,1,2),15,tmp,'filled');
			idx = find(tmp>0.5);
			scatter(candidates(idx,1,1),candidates(idx,1,2),15,tmp(idx),'filled');
			drawnow
		end
	end

	zbin = double(bsxfun(@eq,znew,max(znew)));
	fprintf('\n%f %g %f\n',sum(sum(zbin.*c)),sum(sum(zbin.*c))-val2,sum(max(zbin,[],2)));
	figure(12)
	tmp = max(zbin,[],2);
	scatter(candidates(:,1,1),candidates(:,1,2),15,tmp,'filled');
	idx = find(tmp>0.5);
	hold on
	scatter(candidates(idx,1,1),candidates(idx,1,2),15,tmp(idx),'filled');
	ylim([min(y(:,2)),max(y(:,2))])
	xlim([min(y(:,1)),max(y(:,1))])
	colormap cool
	axis equal
	colorbar
end
