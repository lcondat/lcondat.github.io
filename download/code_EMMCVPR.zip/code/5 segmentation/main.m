% convex relaxation of color image segmentation 
% with spatial regularization using isotropic TV

% Author: Laurent Condat, PhD, https://lcondat.github.io/
% Nov. 26, 2020
% Copyright: Laurent Condat.

% If you use this code, please cite the paper:
% L. Condat, “A Convex Approach to K-means Clustering and Image Segmentation,” EMMCVPR, Oct. 2017, Venice, Italy. 
% In: M. Pelillo and E. Hancock eds., Lecture Notes in Computer Science vol. 10746, Springer, pp. 220-234, 2018.  

function main
	K = 7;
	lambda = 500; % regularization parameter	
	nbiter = 2000; 
	tau = 10; %0.1 %try different values
	mu = 3;  %1 
	gamma = 0.1;  % \in (0,1)
	%we must have tau.(sigma(1+1/mu)+sigma2.8)=1
	sigma = 1/tau/(1+1/mu)*gamma;
	sigma2 = 1/tau/8*(1-gamma);
	rho = 1.9;	
	load('palette279.mat');
	M = size(palette,1); % number of candidates
 	palette = palette/255;
 	%y = double(imread('tournesol2.tif'));
  	%y = double(imread('cocci2.tif'));
 	y = double(imread('parrot2.tif'));
	[height,width,nbcol] = size(y);
	N = width*height; % number of pixels
	sqrtN = sqrt(N*mu);
	figure(1)
	imshow(y/255);
	
	c = sum(bsxfun(@minus, shiftdim(rgb2lab(y/255),-1),reshape(rgb2lab(palette),M,1,1,3)).^2,4);
	cmax = max(c(:))/2;
	c = c/cmax; %heuristic scaling
	lambda = lambda/cmax;
	[tmp, idx] = min(c);
    z = double(bsxfun(@eq, (1:M)', idx));	
	x = shiftdim(sum(bsxfun(@times,z,reshape(palette,M,1,1,3)),1),1);
	figure(2)
	imshow(x);
	
	proj_simplex = @(z) max(bsxfun(@minus,z,max(bsxfun(@rdivide,...
 		cumsum(sort(z,1,'descend'),1)-1,(1:M)'))),0);
 	proj_lec = @(q,a) q-max(sum(q)-a,0)/length(q);  %make the sum of q <= a
 	opL = @(z,q) bsxfun(@minus, z, q/sqrtN);  	
 	opD = @(z) cat(4,cat(2,diff(z,1,2),zeros(M,1,width)),cat(3,diff(z,1,3),zeros(M,height,1)));
 	opDadj = @(u) -cat(2,u(:,1,:,1),diff(u(:,:,:,1),1,2))-cat(3,u(:,:,1,2),diff(u(:,:,:,2),1,3));	
 	prox_sigma2_g_conj = @(v) bsxfun(@rdivide, v, max(sqrt(sum(v.^2,4))/lambda,1));

	u = zeros(size(z));
	q = zeros(M,1); %auxiliary vector used to split the max
	v = zeros(M,height,width,2);
	
	%for iter = 1:nbiter	
	iter = 0;	
	val4 = 0;
	while 1
		iter=iter+1;
		znew = proj_simplex(z - tau*(u+c+opDadj(v)));
		qnew = proj_lec(q + (tau/sqrtN)*sum(sum(u,3),2),sqrtN*K);
		unew = max(u + sigma*opL(2*znew-z,2*qnew-q),0);
    	vnew = prox_sigma2_g_conj(v + sigma2*opD(2*znew-z)); 	
    	z = z + rho*(znew - z);
    	q = q + rho*(qnew - q);
    	u = u + rho*(unew - u);
    	v = v + rho*(vnew - v);
		if mod(iter,10)==0
			val1 = sum(max(max(znew,[],3),[],2)); % feasibility test
			val2 = (sum(znew(:).*c(:)) + ... % primal cost value
				lambda*sum(sum(sum(sqrt(sum(opD(znew).^2,4))))));	
			val3 = sum(sum(min(opDadj(vnew)+unew+c)))-K*max(sum(sum(unew,3),2)); %dual cost value
			if val3>val4, val4=val3; end
			fprintf('%d %.2g %.2f %f %f %f %f\n',iter,val1-K,...
				min(min(max(znew))),val2,val3,val4,val2-val4);
			x = shiftdim(sum(bsxfun(@times,znew,reshape(palette,M,1,1,3)),1),1);
			figure(3)
			imshow(x);
			drawnow
			if iter==nbiter, break; end
		end
	end
	x = shiftdim(sum(bsxfun(@times,znew,reshape(palette,M,1,1,3))),1);
	figure(3)
	imshow(x);
	imwrite(x,'x.tif');
	zbin = double(bsxfun(@eq,znew,max(znew)));
	fprintf('\n%f %g %f\n',(sum(sum(sum(zbin.*c)))+...
		lambda*sum(sum(sum(sqrt(sum(opD(zbin).^2,4))))))/2,...
		sum(sum(sum(zbin.*c)))-val2,sum(max(max(zbin,[],3),[],2)));
	x = shiftdim(sum(bsxfun(@times,zbin,reshape(palette,M,1,1,3))),1);
	figure(4)
	imshow(x);
	imwrite(x,'xbin.tif');
	
	% postprocessing
	idx=find(max(max(zbin,[],3),[],2)==1);
	ylab=rgb2lab(reshape(y,N,3)/255);
	%sum(sum((ylab-rgb2lab(reshape(x,N,3))).^2))/cmax
	if length(idx)==K 
		palette2 = rgb2lab(palette(idx,:));
		rng default;
		[idx,cl] = kmeans(ylab,K,'Start',palette2);
		sum(sum((ylab-cl(idx,:)).^2))/cmax
		cl = lab2rgb(cl);
		xpost = reshape(cl(idx,:),height,width,3);
		figure(5); imshow(xpost);
		imwrite(xpost,'xpost.tif');
	end
	rng default;
	[idx,cl] = kmeans(ylab,K);
	sum(sum((ylab-cl(idx,:)).^2))/cmax
	cl = lab2rgb(cl);
	xkmeans = reshape(cl(idx,:),height,width,3);
	figure(6); imshow(xkmeans);
	imwrite(xkmeans,'xkmeans1.tif');
end

