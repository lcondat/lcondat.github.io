% convex relaxation of grayscale image quantization

% min <z,c> s.t. columns of z on the simplex and sum_rows(max_columns(z))<=K

% Author: Laurent Condat, PhD, https://lcondat.github.io/
% Nov. 26, 2020
% Copyright: Laurent Condat.

% If you use this code, please cite the paper:
% L. Condat, “A Convex Approach to K-means Clustering and Image Segmentation,” EMMCVPR, Oct. 2017, Venice, Italy. 
% In: M. Pelillo and E. Hancock eds., Lecture Notes in Computer Science vol. 10746, Springer, pp. 220-234, 2018.  


function main
	K = 4; % nb of colors in the quantized image
	nbiter = 2000;
	tau = 0.0001;  %0.0001;
	sigma = 1/tau;
	rho = 1.9;		%1.8
 		
	y = imread('lena256.tif');
	[height,width] = size(y);
	figure(1)
	imshow(y);
	[counts,xbins]=imhist(y);
	idx = find(counts); % gray values represented in the image
	
	proj_simplex = @(z) max(bsxfun(@minus,z,max(bsxfun(@rdivide,...
 		cumsum(sort(z,1,'descend'),1)-1,(1:256)'))),0);
 	prox_sigma_g_conj = @(u) u-projl1inf(u,sigma*K);
	z = eye(256);
	c = zeros(256);
	u = zeros(256);
	x = y;
	%c[n,m] = cost if graylevel m is represented by n
	for n=1:256, for m=1:256
		c(n,m)=counts(m)*(n-m)^2/2;
	end, end
	% DR written like a CP
	for iter = 1:nbiter		
		znew = proj_simplex(z - tau*(u+c));
		unew = prox_sigma_g_conj(u + sigma*(2*znew-z));
    	z = znew + (rho-1)*(znew - z);
    	u = unew + (rho-1)*(unew - u);
		if mod(iter,200)==0
			fprintf('%d %f %f %f\n',iter,sum(sum(znew.*c)),sum(max(znew,[],2)),min(max(znew(:,idx))));
			a = sum(bsxfun(@times,znew,(0:255)'));
			fun=@(t) a(t+1);
			x = fun(y);
			figure(2)
			imshow(x/255);
			drawnow
		end
	end
	a = sum(bsxfun(@times,znew,(0:255)'));
	fun=@(t) a(t+1);
	x = fun(y);
	figure(2)
	imshow(x/255);
	imwrite(uint8(x),'x.tif');
	find(max(znew,[],2))-1 % prints the gray levels
	
	[val,idx2]=max(znew);
	z = zeros(256);
	for m=1:256
		z(idx2(m),m)=1;
	end
	fprintf('%f %f %f\n',sum(sum(z.*c)),sum(max(z,[],2)),min(max(z(:,idx))));
	fun=@(t) idx2(t+1)-1;
	x = fun(y);
	
	figure(3)
	imshow(x/255);
	imwrite(uint8(x),'xbin.tif');
end
