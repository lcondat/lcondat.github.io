#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "image.h"

extern int SWAP_BOOL; 	/*0 for Windows and Mac Intel, 1 for Mac PowerPC. Controls the little/big endianness*/

/*Check function for the mallocs*/
void* Check(void* pointer) {
	if (pointer == NULL) {
		printf("Memory allocation error\n");
		exit(1);
	}
	return pointer;
}


static void SwapBuffer (Image* Source, char reverse) {
	int    res;
	uint32* 	cursS;
	uint32* 	cursD;
	uint32		pixel;
	int		x, y;
	int		width = Source->width;
	int		height = Source->height;
	uint32*		Dest;
	
  	Dest = (uint32*)Check(_TIFFmalloc(width * height * sizeof(uint32)));
	cursS = Source->dataI;
	cursD = Dest + (height - 1) * width;
	for (y = 0; y < height; y++) {
		for (x = 0; x < width; x++) {
			pixel = *cursS;
			if (reverse)
				pixel =	((pixel & 0xFF000000) >> 24) |
					((pixel & 0x00FF0000) >>  8) |
					((pixel & 0x0000FF00) <<  8) |
					((pixel & 0x000000FF) << 24);
			*cursD = pixel;
			cursS++;
			cursD++;
		}
		cursD -= 2 * width;
	}
	_TIFFfree ((tdata_t)(Source->dataI));
	Source->dataI = Dest;
}


static void LoadPixels (TIFF* file, Image* Dest) {
  	int     res;
	
	res = TIFFGetField (file, TIFFTAG_IMAGEWIDTH, &(Dest->width));
  	if (res != 1) {
    		printf ("Tag IMAGEWIDTH was not found in tiff file\n");
    		exit(1);
  	}
	res = TIFFGetField (file, TIFFTAG_IMAGELENGTH, &(Dest->height));
  	if (res != 1) {
    		printf ("Tag IMAGEHEIGHT was not found in tiff file\n");
    		exit(1);
  	}
  	/* Allocate memory for the pixels and load them from file */
	Dest->dataI = (uint32*)Check(malloc(Dest->width * Dest->height * sizeof(uint32)));
  	res = TIFFReadRGBAImage (file, Dest->width, Dest->height, Dest->dataI, 0);
  	if (res != 1) {
    		printf ("Could not load image pixels into memory\n");
    		free ((tdata_t)(Dest->dataI));
    		exit(1);
  	}  
}


void LoadImage(Image* Dest, char* name) {
	TIFF*     	File;
  	File = TIFFOpen (name, "r");	
  	if (File == (TIFF*)NULL) {
    		printf ("Could not open file named %s for reading.\n", name);
    		exit (1);
  	}
	LoadPixels (File, Dest);	
	TIFFClose (File);			
	SwapBuffer (Dest, SWAP_BOOL); 
}


static void SavePixels (TIFF* file, Image* Source) {
  	int     res;
	int	width = Source->width;
	int	height = Source->height;
  	
  	res =   TIFFSetField (file, TIFFTAG_IMAGEWIDTH, width);
  	if (res == 1)
    		res = TIFFSetField (file, TIFFTAG_IMAGELENGTH, height);
  	if (res == 1)
    		res = TIFFSetField (file, TIFFTAG_BITSPERSAMPLE, (uint16)8);
  	if (res == 1)
    		res = TIFFSetField (file, TIFFTAG_PHOTOMETRIC, (uint16)2);
  	if (res == 1)
    		res = TIFFSetField (file, TIFFTAG_SAMPLESPERPIXEL, (uint16)4);
  	if (res == 1)
    		res = TIFFSetField (file, TIFFTAG_PLANARCONFIG, (uint16)PLANARCONFIG_CONTIG);
	if (res == 1) {
    		res = (int)TIFFWriteRawStrip (file, 0, Source->dataI, sizeof(uint32) * width * height);
		if (res == -1) res = 0;
	}	
  	if (res == 0) {
    		printf ("An error occured while trying to save TIFF file\n");
    		exit(1);
  	}
}

/*saves the image as a TIFF file*/
void SaveImage(Image* Source, char* name) {
	TIFF*     	File;
  	File = TIFFOpen (name, "w");	
   	if (File == (TIFF*)NULL) {
    		printf ("Could not open file named %s for writing.\n", name);
    		exit (1);
  	}
	SavePixels (File, Source);	
	TIFFClose (File);			
}


uint8 truncint (int i) {
	if (i<=0) return 0;
	if (i>=255) return 255;
	return (uint8)i;
}

uint8 truncfloat(float f) {
	long i = floor(f+0.5);
	if (i>=255) return (uint8)255;
	if (i<=0) return (uint8)0;
	return (uint8)i;
}



/*converts the float buffers into the buffer Source.dataI for writing the image as a TIFF file.
The image will be written as a COLOR image. If channel>0, the three R,G,B channels will be equal.*/
void Float_to_int(Image *Source, int channel) {
	float* 	curs = Source->dataF;
	float* 	curs2 = Source->dataF2;
	float* 	curs3 = Source->dataF3;
	uint8*  pixd;
	int 	i,j;
	int 	width = Source->width;
	int 	height = Source->height;
	
	Source->dataI=(uint32*)Check(_TIFFmalloc(width * height * sizeof(uint32)));
	if (channel != 0) {
		if (channel == 1) 
			curs2 = curs3 = curs;
		else if (channel == 2) 
			curs = curs3 = curs2;
		else if (channel == 3) 
			curs = curs2 = curs3;
		else {
			printf("Bad value of channel\n");
			exit(1);
		}
	}	
	pixd = (uint8*)(Source->dataI);
	for (i=0;i<height;i++) {
		for (j=0;j<width;j++) {
			*pixd++ = truncfloat(*curs++);
			*pixd++ = truncfloat(*curs2++);
			*pixd++ = truncfloat(*curs3++);
			*pixd++ = 255;		/*alpha channel*/
		}
	}
}


/*converts the raw data of the TIFF file (uint8 pixel values) into buffers of floats*/
void Int_to_float(Image* Source, int channel) {
	uint8* 	curs;
	float*  pixd;
	int 	width = Source->width;
	int 	height = Source->height;
	int 	i,j;
	
	if ((channel==0) || (channel==1)) {
		Source->dataF=(float*)Check(malloc(width * height * sizeof(float)));
		pixd = Source->dataF;
		curs = (uint8*)(Source->dataI);
		for (i=0; i<height*width; i++) {
			*pixd++ = *curs;
			curs+=4;
		}
	}
	if ((channel==0) || (channel==2)) {
		Source->dataF2=(float*)Check(malloc (width * height * sizeof(float)));
		curs = (uint8*)(Source->dataI) + 1;
		pixd = Source->dataF2;
		for (i=0; i<height*width; i++) {
			*pixd++ = *curs;
			curs+=4;
		}
	}
	if ((channel==0) || (channel==3)) {
		Source->dataF3=(float*)Check(malloc (width * height * sizeof(float)));
		curs = (uint8*)(Source->dataI) + 2;
		pixd = Source->dataF3;
		for (i=0; i<height*width; i++) {
			*pixd++ = *curs;
			curs+=4;
		}
	}
}


/* Grayscale Images assumed.
computes the MSE and PSNR between Source1 and Source2. If Diff!=NULL, the difference is put in Diff as a grayscale image
the value border allows not to take into account the first and last <border> rows and columns of the image for the computation of the error*/
void Difference(Image* Source1, Image* Source2, Image* Diff, int border) {
	uint8* 	pixs1 = (uint8*)(Source1->dataI);
	uint8* 	pixs2 = (uint8*)(Source2->dataI);
	uint8* 	pixd;
	int 	i,j,k;
	unsigned long 	erreur2 = 0;
	double  e1, e2, em, PSNR;
	int		diff;
	int    	width = Source1->width;
	int		height = Source1->height;
	
	if (width != Source2->width) {
		printf("Error: images should have the same width for computing their difference: %d!=%d\n",
			width,Source2->width);
		exit(1);
	}
	else if (height != Source2->height) {
		printf("Error: images should have the same height for computing their difference: %d!=%d\n",
			height,Source2->height);
		exit(1);
	}
	if (Diff != NULL) {
		Diff->dataI=(uint32*)Check(_TIFFmalloc (width*height*sizeof(uint32)));
		pixd = (uint8*)(Diff->dataI);
		Diff->width = width;
		Diff->height = height;
	}
	for (i=0; i<height; i++) {
		for (j=0; j<width; j++) {
			diff = *pixs2 - *pixs1;
			if ((i>=border) && (i<height-border) && (j>=border) && (j<width-border)) 
				erreur2 += diff*diff;
			if (Diff != NULL) {
				*(pixd++) = truncint(diff+128);
				*(pixd++) = truncint(diff+128);
				*(pixd++) = truncint(diff+128);
				*(pixd++) = 255;
			}
			pixs1 += 4; 
			pixs2 += 4;
		}
	}		
 	e2 = (double)erreur2 / ((width-2*border) * (height-2*border));
	PSNR = 10.0*log10(255.0*255.0/e2);
	printf("MSE :     %f\n",e2);
	printf("PSNR :     %f\n",PSNR);
}


/*crops the image by removing rows and columns at the borders*/
int Crop(Image* Source, Image* Dest, int newwidth, int newheight) {
	int 	width = Source->width;
	int 	height = Source->height;
	int		i,j,k,l;
	float* 	Buffer;
	float* 	pixd;
	float*	pixs;

	Check(Buffer = (float*)Check(malloc(newwidth*newheight*sizeof(float))));
	pixd = Buffer;
	pixs = Source->dataF;

	pixs += (height-newheight)/2*width;
	for (i=0; i<newheight; i++) {
		memcpy(pixd, pixs+(width-newwidth)/2, newwidth*sizeof(float));
		pixs += width;
		pixd += newwidth;
	}
	if (Dest == NULL) {
		Source->width = newwidth;
		Source->height = newheight;
		free(Source->dataF);
		Source->dataF = Buffer;
	} else {
		Dest->width = newwidth;
		Dest->height = newheight;
		Dest->dataF = Buffer;
	}
}


/*extends the size of the image by adding rows and columns at the borders. The new pixel values are computed by mirror symmetry*/
void Extend(Image* Source, Image* Dest, int borderx, int bordery) {
	int width = Source->width;
	int height = Source->height;
	int i,j;
	int newwidth = width+2*borderx;
	int newheight = height+2*bordery;
	float* Buffer=(float*)Check(malloc(newwidth*newheight*sizeof(float)));
	for (i=0; i<bordery; i++) 
		for (j=0; j<width; j++) 
			Buffer[i*newwidth+j+borderx]=Source->dataF[(bordery-i)*width+j];
	for (i=0; i<height; i++) 
		for (j=0; j<width; j++) 
			Buffer[(bordery+i)*newwidth+j+borderx]=Source->dataF[i*width+j];
	for (i=0; i<bordery; i++) 
		for (j=0; j<width; j++) 
			Buffer[(bordery+height+i)*newwidth+j+borderx]=Source->dataF[(height-2-i)*width+j];
	for (i=0; i<borderx; i++) 
		for (j=0; j<newheight; j++) {
			Buffer[j*newwidth+i]=Buffer[j*newwidth+2*borderx-i];
			Buffer[j*newwidth+borderx+width+i]=Buffer[j*newwidth+borderx+width-2-i];
		}		
	if (Dest==NULL) {
		Source->width = newwidth;
		Source->height = newheight;
		free(Source->dataF);
		Source->dataF = Buffer;
	} else {
		Dest->dataF = Buffer;
		Dest->width = newwidth;
		Dest->height = newheight;
	}
}


