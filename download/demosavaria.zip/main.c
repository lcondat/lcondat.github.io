/*
Program for image demosaicking based on a variational formalism, as described in the article:

L. Condat,  “A generic variational approach for demosaicking from an arbitrary color filter array,” 
IEEE ICIP, Nov. 2009, Cairo, Egypt.
(PDF available on the homepage of L. Condat).

Written by Laurent Condat.
Please report any bug or comment to laurent.condat@greyc.ensicaen.fr.
Very few tests done with this code, so be indulgent! 
v. 1.0 - Jan. 2010
v. 1.1 - Mar. 2010  bugs lines 301 & 336 corrected. Aperiodic CFA with CMY filters added (RANDOMCMY).


Compile with make
execute by ./main <your image in TIFF format>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You can receive a copy of the GNU General Public License
by writing to the Free Software Foundation,
Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <tiffio.h>
#include "image.h"

int SWAP_BOOL = 0; 	/*0 for Windows PC and Mac Intel, 1 for Mac PowerPC. Controls the little/big endianness*/

#define BAYER 1
#define CMY 2
#define HIRAKAWA 3
#define CONDAT 4
#define KODAK 5
#define RANDOM 6
#define RANDOMCMY 7

int 	CFA=RANDOMCMY;
int 	NBITER = 100;  /*number of iterations, including the 10 first iterations with mu=1 for initialization.
20 should be enough for smooth images like the Kodak images, push to 100 or more for sharper images.*/
double 	MU=0.4;	/*weight for the luminance energy, 0<mu<=1. Recommendation for the Kodak images: 0.04 for BAYER and RANDOM, 0.12 for HIRAKAWA, KODAK and CMY. Values roughly tested, to be proofed. 
For sharper images, MU should be higher. For instance, for the test image testimage.tif, MU=0.5 works fine with the Bayer CFA, MU=0.4 for the random CFA.*/


void Usage (int argc, char* argv[]) {		/*imprime la ligne de commande correcte en cas d'erreur*/
  	printf ("Bad number of parameters: should be \"");
  	printf ("%s <source_file_name> \"\n", argv[0]);
}


/*Conversion from RGB to luminance, blue/yellow and green/red chrominance*/
void RGBtoLCC(Image* Source, Image* Dest){
	float*	pixR = Source->dataF;
	float*	pixG = Source->dataF2;
	float*	pixB = Source->dataF3;
	int		i;
	int		width = Source->width;
	int		height = Source->height;
	float* 	BufferY = (float*)Check(malloc(width*height*sizeof(float)));
	float* 	BufferC1 = (float*)Check(malloc(width*height*sizeof(float)));
	float* 	BufferC2 = (float*)Check(malloc(width*height*sizeof(float)));
	float*	pixY = BufferY;
	float*	pixC1 = BufferC1;
	float*	pixC2 = BufferC2;
	double sq3=sqrt(3.0);
	double sq2=sqrt(2.0);
	
	for (i=0; i<width*height; i++) {
		*pixY++ = (*pixR + *pixG + *pixB)/sq3;
		*pixC1++ =  (*pixB++ - *pixR/2.0 - *pixG/2.0)*sq2/sq3;
		*pixC2++ = (-*pixR++ + *pixG++)/sq2;
	}
	if (Dest == NULL) {		/*in-place conversion in Source*/
		free(Source->dataF);
		free(Source->dataF2);
		free(Source->dataF3);
		Source->dataF = BufferY;
		Source->dataF2 = BufferC1;
		Source->dataF3 = BufferC2;
	} else {
		Dest->width = width;
		Dest->height = height;
		Dest->dataF = BufferY;
		Dest->dataF2 = BufferC1;
		Dest->dataF3 = BufferC2;
	}
}


void LCCtoRGB(Image* Source, Image* Dest){
	float*	pixY = Source->dataF;
	float*	pixC1 = Source->dataF2;
	float*	pixC2 = Source->dataF3;
	int		i;
	int		width = Source->width;
	int		height = Source->height;
	float* 	BufferR = (float*)Check(malloc(width*height*sizeof(float)));
	float* 	BufferG = (float*)Check(malloc(width*height*sizeof(float)));
	float* 	BufferB = (float*)Check(malloc(width*height*sizeof(float)));
	float*	pixR = BufferR;
	float*	pixG = BufferG;
	float*	pixB = BufferB;
	double sq3=sqrt(3.0);
	double sq2=sqrt(2.0);
	
	for (i=0; i<width*height; i++) {
		*pixR++ = *pixY/sq3 - *pixC1/sq2/sq3 - *pixC2/sq2;
		*pixB++ = *pixY/sq3 + *pixC1*sq2/sq3;
		*pixG++ = *pixY++/sq3 - *pixC1++/sq2/sq3 + *pixC2++/sq2;
	}
	if (Dest == NULL) {		/*in-place conversion in Source*/
		free(Source->dataF);
		free(Source->dataF2);
		free(Source->dataF3);
		Source->dataF = BufferR;
		Source->dataF2 = BufferG;
		Source->dataF3 = BufferB;
	} else {
		Dest->width = width;
		Dest->height = height;
		Dest->dataF = BufferR;
		Dest->dataF2 = BufferG;
		Dest->dataF3 = BufferB;
	}
}


int random_bool() {	/*uniform distribution in the set {0,1}*/
	double aux=(double)rand()/(double)RAND_MAX;
	if (aux<0.5) return 0;
	else return 1;
}


int RGBval(float R, float G, float B) {
	if (R==255.0) return 0;
	else if (G==255.0) return 1;
	else return 2;
}


void Mosaicking (Image* Source, Image* Dest, Image* Cfaim, int method) {
	int i,j,pos;
	int width = Source->width;
	int height = Source->height;
	Dest->width=width;
	Dest->height=height;
	Dest->dataF=(float*)Check(malloc(width*height*sizeof(float)));
	Cfaim->width=width;
	Cfaim->height=height;
	Cfaim->dataF=(float*)Check(calloc(width*height,sizeof(float)));
	Cfaim->dataF2=(float*)Check(calloc(width*height,sizeof(float)));
	Cfaim->dataF3=(float*)Check(calloc(width*height,sizeof(float)));
	
	if (method==BAYER) {
		for (i=0; i<height; i++) {
			for (j=0; j<width; j++) {
				if ((i+j)%2==0) {
					Cfaim->dataF2[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j];
				} else if (j%2==1) {
					Cfaim->dataF[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF[i*width+j];
				} else {
					Cfaim->dataF3[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF3[i*width+j];
				}
			}
		}
	} else if (method==CMY) {
		for (i=0; i<height; i++) {
			for (j=0; j<width; j++) {
				if ((i+j)%2==0) {
					Cfaim->dataF[i*width+j]=255.0;
					Cfaim->dataF2[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]+
						Source->dataF2[i*width+j];
				} else if (j%2==1) {
					Cfaim->dataF2[i*width+j]=255.0;
					Cfaim->dataF3[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j]+
						Source->dataF3[i*width+j];
				} else {
					Cfaim->dataF[i*width+j]=255.0;
					Cfaim->dataF3[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]+
						Source->dataF3[i*width+j];
				}
			}
		}
	} else if (CFA==KODAK) {
		for (i=0; i<height; i++) {
			for (j=0; j<width; j++) {
				pos=(i%4)*4+(j%4);
				if ((i+j)%2==0) {
					Cfaim->dataF[i*width+j]=255.0;
					Cfaim->dataF2[i*width+j]=255.0;
					Cfaim->dataF3[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]+
						Source->dataF2[i*width+j]+Source->dataF3[i*width+j];
				} else if ((pos==3)||(pos==6)||(pos==9)||(pos==12)) {
					Cfaim->dataF2[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j];
				} else if ((pos==1)||(pos==4)) {
					Cfaim->dataF3[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF3[i*width+j];
				} else {
					Cfaim->dataF[i*width+j]=255.0;
					Dest->dataF[i*width+j]=Source->dataF[i*width+j];
				}
			}
		}
	} else if (CFA==HIRAKAWA) {
		for (i=0; i<height; i++) {
			for (j=0; j<width; j++) {
				pos=(i%4)*2+(j%2);
				if ((pos==0)||(pos==7)) {
					Cfaim->dataF[i*width+j]=255.0;
					Cfaim->dataF3[i*width+j]=127.5;
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]+Source->dataF3[i*width+j]/2.0;
				} else if ((pos==2)||(pos==5)) {
					Cfaim->dataF3[i*width+j]=255.0;
					Cfaim->dataF[i*width+j]=127.5;
					Dest->dataF[i*width+j]=Source->dataF3[i*width+j]+Source->dataF[i*width+j]/2.0;
				} else if ((pos==1)||(pos==6)) {
					Cfaim->dataF2[i*width+j]=255.0;
					Cfaim->dataF3[i*width+j]=127.5;
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j]+Source->dataF3[i*width+j]/2.0;
				} else {
					Cfaim->dataF2[i*width+j]=255.0;
					Cfaim->dataF[i*width+j]=127.5;
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j]+Source->dataF[i*width+j]/2.0;
				}
			}
		}
	} else if (CFA==CONDAT) {
		for (i=0; i<height; i++) {
			for (j=0; j<width; j++) {
				pos = (j%2)*3+(i%3);
				if (pos==0) {
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j]/2.0+Source->dataF3[i*width+j];
					Cfaim->dataF2[i*width+j]=127.5;
					Cfaim->dataF3[i*width+j]=255.0;
				} else if (pos==1) {
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]/2.0+Source->dataF2[i*width+j];
					Cfaim->dataF[i*width+j]=127.5;
					Cfaim->dataF2[i*width+j]=255.0;
				} else if (pos==2) {
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]+Source->dataF3[i*width+j]/2.0;
					Cfaim->dataF[i*width+j]=255.0;
					Cfaim->dataF3[i*width+j]=127.5;
				} else if (pos==3) {
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]+Source->dataF2[i*width+j]/2.0;
					Cfaim->dataF[i*width+j]=255.0;
					Cfaim->dataF2[i*width+j]=127.5;
				} else if (pos==4) {
					Dest->dataF[i*width+j]=Source->dataF[i*width+j]/2.0+Source->dataF3[i*width+j];
					Cfaim->dataF[i*width+j]=127.5;
					Cfaim->dataF3[i*width+j]=255.0;
				} else if (pos==5) {
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j]+Source->dataF3[i*width+j]/2.0;
					Cfaim->dataF2[i*width+j]=255.0;
					Cfaim->dataF3[i*width+j]=127.5;
				}	
			}
		}
	} else if ((CFA==RANDOM)||(CFA==RANDOMCMY)) {
		int col1,col2, col3, col, triplet, k;
		int coltab1[9]={0,2,1,2,1,0,1,0,2};
		int coltriplet[18]={0,1,2,0,2,1,1,2,0,1,0,2,2,0,1,2,1,0};
		int nexttriplet[12]={1,3,0,4,3,5,0,2,1,5,2,4};
		triplet=0;
		for (k=0; k<=2; k++) {
			col=coltriplet[triplet*3+k];
			if (col==0) {
				Dest->dataF[k]=Source->dataF[k];
				Cfaim->dataF[k]=255.0;
				Dest->dataF[k*width]=Source->dataF[k*width];
				Cfaim->dataF[k*width]=255.0;
			} else if (col==1) {
				Dest->dataF[k]=Source->dataF2[k];
				Cfaim->dataF2[k]=255.0;
				Dest->dataF[k*width]=Source->dataF2[k*width];
				Cfaim->dataF2[k*width]=255.0;
			} else if (col==2) {
				Dest->dataF[k]=Source->dataF3[k];
				Cfaim->dataF3[k]=255.0;
				Dest->dataF[k*width]=Source->dataF3[k*width];
				Cfaim->dataF3[k*width]=255.0;
			}
		}
		for (j=3; j<width-2; j+=3) {
			if (random_bool()) triplet=nexttriplet[triplet*2+1];
			else triplet=nexttriplet[triplet*2];
			for (k=0; k<=2; k++) {
				col=coltriplet[triplet*3+k];
				if (col==0) {
					Dest->dataF[j+k]=Source->dataF[j+k];
					Cfaim->dataF[j+k]=255.0;
				} else if (col==1) {
					Dest->dataF[j+k]=Source->dataF2[j+k];
					Cfaim->dataF2[j+k]=255.0;
				} else if (col==2) {
					Dest->dataF[j+k]=Source->dataF3[j+k];
					Cfaim->dataF3[j+k]=255.0;
				}
			}
		}
		if (j<width) {
			if (random_bool()) triplet=nexttriplet[triplet*2+1];
			else triplet=nexttriplet[triplet*2];
			for (; j<width; j++) {
				col=coltriplet[triplet*3+(j%3)];
				if (col==0) {
					Dest->dataF[j]=Source->dataF[j];
					Cfaim->dataF[j]=255.0;
				} else if (col==1) {
					Dest->dataF[j]=Source->dataF2[j];
					Cfaim->dataF2[j]=255.0;
				} else if (col==2) {
					Dest->dataF[j]=Source->dataF3[j];
					Cfaim->dataF3[j]=255.0;
				}
			}
		}
		triplet=0;
		for (i=3; i<height-2; i+=3) {
			if (random_bool()) triplet=nexttriplet[triplet*2+1];
			else triplet=nexttriplet[triplet*2];
			for (k=0; k<=2; k++) {
				col=coltriplet[triplet*3+k];
				if (col==0) {
					Dest->dataF[(i+k)*width]=Source->dataF[(i+k)*width];
					Cfaim->dataF[(i+k)*width]=255.0;
				} else if (col==1) {
					Dest->dataF[(i+k)*width]=Source->dataF2[(i+k)*width];
					Cfaim->dataF2[(i+k)*width]=255.0;
				} else if (col==2) {
					Dest->dataF[(i+k)*width]=Source->dataF3[(i+k)*width];
					Cfaim->dataF3[(i+k)*width]=255.0;
				}
			}
		}
		if (i<height) {
			if (random_bool()) triplet=nexttriplet[triplet*2+1];
			else triplet=nexttriplet[triplet*2];
			for (; i<height; i++) {
				col=coltriplet[triplet*3+(i%3)];
				if (col==0) {
					Dest->dataF[i*width]=Source->dataF[i*width];
					Cfaim->dataF[i*width]=255.0;
				} else if (col==1) {
					Dest->dataF[i*width]=Source->dataF2[i*width];
					Cfaim->dataF2[i*width]=255.0;
				} else if (col==2) {
					Dest->dataF[i*width]=Source->dataF3[i*width];
					Cfaim->dataF3[i*width]=255.0;
				}
			}
		}
		for (i=1; i<height; i++) {
			for (j=1; j<width; j++) {
				col1=RGBval(Cfaim->dataF[(i-1)*width+j],Cfaim->dataF2[(i-1)*width+j],
					Cfaim->dataF3[(i-1)*width+j]);
				col2=RGBval(Cfaim->dataF[i*width+j-1],Cfaim->dataF2[i*width+j-1],
					Cfaim->dataF3[i*width+j-1]);
				if (col1==col2) {
					col3=RGBval(Cfaim->dataF[(i-1)*width+j-1],Cfaim->dataF2[(i-1)*width+j-1],
					Cfaim->dataF3[(i-1)*width+j-1]);
					col=coltab1[col1*3+col3];
				} else col=coltab1[col1*3+col2];
				if (col==0) {
					Dest->dataF[i*width+j]=Source->dataF[i*width+j];
					Cfaim->dataF[i*width+j]=255.0;
				} else if (col==1) {
					Dest->dataF[i*width+j]=Source->dataF2[i*width+j];
					Cfaim->dataF2[i*width+j]=255.0;
				} else if (col==2) {
					Dest->dataF[i*width+j]=Source->dataF3[i*width+j];
					Cfaim->dataF3[i*width+j]=255.0;
				}
			}
		}
		if (CFA==RANDOMCMY) {
			for (i=0; i<height; i++) {
				for (j=0; j<width; j++) {
					if (Cfaim->dataF[i*width+j]==255.0) {
						Dest->dataF[i*width+j]=Source->dataF2[i*width+j]+Source->dataF3[i*width+j];
						Cfaim->dataF[i*width+j]=0.0;
						Cfaim->dataF2[i*width+j]=255.0;
						Cfaim->dataF3[i*width+j]=255.0;
					} else if (Cfaim->dataF2[i*width+j]==255.0) {
						Dest->dataF[i*width+j]=Source->dataF[i*width+j]+Source->dataF3[i*width+j];
						Cfaim->dataF2[i*width+j]=0.0;
						Cfaim->dataF[i*width+j]=255.0;
						Cfaim->dataF3[i*width+j]=255.0;
					} else {
						Dest->dataF[i*width+j]=Source->dataF[i*width+j]+Source->dataF2[i*width+j];
						Cfaim->dataF3[i*width+j]=0.0;
						Cfaim->dataF[i*width+j]=255.0;
						Cfaim->dataF2[i*width+j]=255.0;
					}
				}
			}
		}
	}
}

/*The filter is square of size: size x size, where size is odd.*/
/*For a color image, channel=0. channel=1 for a grayscale image*/
/*Full-sample mirror symmetry boundary conditions*/
void Convolution_2D_nonsep(Image* Source, Image* Dest, float filter[], int size, 
	char channel) {	
	
	long	i,j,k,l,nx,ny;
	float 	pixr;
	float*	source;
	float* 	pixd;
	float*	value;
	int		width = Source->width;
	int		height = Source->height;
	float*	data;
	int		px,py;
	int 	sign;
	if (channel==0) {
		Convolution_2D_nonsep(Source, Dest, filter, size, 1);
		Convolution_2D_nonsep(Source, Dest, filter, size, 2);
		Convolution_2D_nonsep(Source, Dest, filter, size, 3);
		return;
	}
	else if (channel==1) source=Source->dataF;
	else if (channel==2) source=Source->dataF2;
	else if (channel==3) source=Source->dataF3;
	else {
		printf ("Error with the channel value\n");
		exit(1);
	}		
	data = (float*)Check(malloc(width * height * sizeof(float)));
	if (data == (float*)NULL) {
		printf ("Could not allocate memory\n");
		exit(1);
	}
	pixd = data;
	for (i=0; i<height; i++) {
		for (j=0; j<width; j++) {
			pixr = 0.0;
			for(k=-size/2; k<=size/2; k++) {
				for(l=-size/2; l<=size/2; l++) {
					px=j+l;
					py=i+k;
					if (px>=width) px=2*width-2-px;
					else if (px<0) px=-px;
					if (py>=height) py=2*height-2-py;
					else if (py<0) py=-py;
					pixr += *(source + py*width + px)*filter[(size/2-k)*size+size/2-l];
				}
			}
			*pixd++ = pixr;
		}
	}
	if (Dest == NULL) {
		free(source);
		if (channel==1) Source->dataF = data;
		else if (channel==2) Source->dataF2 = data;
		else if (channel==3) Source->dataF3 = data;
	} else {
		Dest->width = width;
		Dest->height = height;
		if (channel==1) Dest->dataF = data;
		else if (channel==2) Dest->dataF2 = data;
		else if (channel==3) Dest->dataF3 = data;
	}
}


void Demosaicking (Image* Source, Image* Dest, Image* Cfaim, int Nbiter, double mu) {
	int 	width, height;
	int		i,j;
	int 	iter;
	float 	laplacian[9]={0.0, -0.25, 0.0, -0.25 , 0.0, -0.25, 0.0, -0.25, 0.0};	
	/*most simple Laplacian. Trick: its central coefficients has been set to 0.*/
	double 	mu2=1.0;
	Image 	Residual=EMPTY;
	double 	lambda;
	double	cL,cC1,cC2;
	double 	tabC1[3]={-1/sqrt(6.0),-1/sqrt(6.0),2/sqrt(6.0)};
  	double 	tabC2[3]={-1/sqrt(2.0),1/sqrt(2.0),0.0};
  	double 	tabL[3]={1/sqrt(3.0),1/sqrt(3.0),1/sqrt(3.0)};
	
	width = Source->width;
	height = Source->height;
	Dest->width=width;
	Dest->height=height;
	Dest->dataF=(float*)Check(calloc(width*height,sizeof(float)));
	Dest->dataF2=(float*)Check(calloc(width*height,sizeof(float)));
	Dest->dataF3=(float*)Check(calloc(width*height,sizeof(float)));
	  	
	for (i=0; i<width*height; i++) 
		Dest->dataF[i]=Dest->dataF2[i]=Dest->dataF3[i]=127.5;
	
	RGBtoLCC(Dest,NULL);	
	
	for (iter=0; iter<Nbiter; iter++) {
		Convolution_2D_nonsep(Dest, &Residual, laplacian, 3, 0);
		if (iter==10) mu2=mu;
		for (i=0; i<height; i++) {
			for (j=0; j<width; j++) {	
				cL=(tabL[0]*Cfaim->dataF[i*width+j]+tabL[1]*Cfaim->dataF2[i*width+j]+
					tabL[2]*Cfaim->dataF3[i*width+j])/255.0;
				cC1=(tabC1[0]*Cfaim->dataF[i*width+j]+tabC1[1]*Cfaim->dataF2[i*width+j]+
					tabC1[2]*Cfaim->dataF3[i*width+j])/255.0;
				cC2=(tabC2[0]*Cfaim->dataF[i*width+j]+tabC2[1]*Cfaim->dataF2[i*width+j]+
					tabC2[2]*Cfaim->dataF3[i*width+j])/255.0;
				lambda=-(Residual.dataF[i*width+j]*cL+Residual.dataF2[i*width+j]*cC1+
					Residual.dataF3[i*width+j]*cC2+Source->dataF[i*width+j])/(cL*cL/mu2+cC1*cC1+cC2*cC2);
				Dest->dataF[i*width+j]=-(Residual.dataF[i*width+j]+lambda/mu2*cL);
				Dest->dataF2[i*width+j]=-(Residual.dataF2[i*width+j]+lambda*cC1);
				Dest->dataF3[i*width+j]=-(Residual.dataF3[i*width+j]+lambda*cC2);
			}
		}
		free(Residual.dataF);
		free(Residual.dataF2);
		free(Residual.dataF3);
	}
	LCCtoRGB(Dest,NULL);
}

	
int main (int argc, char* argv[]) {
  	Image	  	Original = EMPTY;
	Image	  	Mosaicked = EMPTY;
	Image	  	Demosaicked = EMPTY;
	Image	  	Cfaim = EMPTY;
	int 		width, height;
			
	if (argc != 2) {	/*en cas d'erreur de l'utilisateur*/
    		Usage (argc, argv);
    		exit (1);
  	}
		
	LoadImage (&Original, argv[1]);
	width = Original.width;
	height = Original.height;
	Int_to_float(&Original, 0);
	SaveImage(&Original,"original.tif");
	_TIFFfree ((tdata_t)(Original.dataI));
	
	Mosaicking(&Original, &Mosaicked, &Cfaim, CFA);
		
	Float_to_int(&Mosaicked, 1);
	SaveImage(&Mosaicked,"mosaicked.tif");
	_TIFFfree ((tdata_t)(Mosaicked.dataI));
		
	Float_to_int(&Cfaim, 0);			
	SaveImage(&Cfaim,"cfa.tif");
	_TIFFfree ((tdata_t)(Cfaim.dataI));
	
	Demosaicking(&Mosaicked, &Demosaicked, &Cfaim, NBITER, MU);
	
	Float_to_int(&Demosaicked, 0);			
	SaveImage(&Demosaicked,"demosaicked.tif");
	_TIFFfree ((tdata_t)(Demosaicked.dataI));
	
	free(Demosaicked.dataF);
	free(Demosaicked.dataF2);
	free(Demosaicked.dataF3);
	free(Cfaim.dataF);
	free(Cfaim.dataF2);
	free(Cfaim.dataF3);
	free(Mosaicked.dataF);
	free(Original.dataF);
	free(Original.dataF2);
	free(Original.dataF3);
}


