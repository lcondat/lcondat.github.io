#ifndef _IMAGE_H
#define _IMAGE_H

#include <tiffio.h>	/*for the formats uint32 et uint8*/
#include <string.h>  /*for the function memcpy*/


/*Our image structure*/
typedef struct {
	int width, height;	
	float* dataF;		/*Buffer of floats*/
	float* dataF2;		/*Buffer of floats*/
	float* dataF3;		/*Buffer of floats*/
	uint32* dataI;		/*Buffer of ints (raw data of the TIFF file)*/
} Image;

#define 	EMPTY  {0,0,NULL,NULL} 


/*loads the TIFF image into the image structure*/
void LoadImage(Image* Dest, char* name);


/*saves the image as a TIFF file*/
void SaveImage(Image* Source, char* name);


/*converts the float buffers into the buffer Source.dataI for writing the image as a TIFF file.
The image will be written as a COLOR image.*/
void Float_to_int(Image *Source, int channel);


/*converts the raw data of the TIFF file (uint8 pixel values) into buffers of floats*/
void Int_to_float(Image* Source, int channel);


/* Grayscale Images assumed.
computes the MSE and PSNR between Source1 and Source2. If Diff!=NULL, the difference is put in Diff as a grayscale image
the value border allows not to take into account the first and last <border> rows and columns of the image for the computation of the error*/
void Difference(Image* Source1, Image* Source2, Image* Diff, int border);


/*crops the image by removing rows and columns at the borders*/
int Crop(Image* Source, Image* Dest, int newwidth, int newheight);


/*extends the size of the image by adding rows and columns at the borders. The new pixel values are computed by mirror symmetry*/
void Extend(Image* Source, Image* Dest, int borderx, int bordery);


/*Check function for the mallocs*/
void* Check(void* pointer);

#endif